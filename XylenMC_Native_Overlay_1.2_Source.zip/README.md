# XylenMC Client Edition — Native Android Overlay 1.2

Native Kotlin + Jetpack Compose Android overlay companion for Minecraft Bedrock. See [README_ID.md](README_ID.md) for Indonesian setup, feature scope, build workflow, and limitations.
