# XylenMC Client Edition — Native Android Overlay 1.2

Paket ini adalah proyek Android native Kotlin + Jetpack Compose. Ini BUKAN website/WebView dan bukan Add-on Minecraft. Fokusnya adalah aplikasi pendamping dengan floating overlay di atas Minecraft Bedrock.

## Tampilan yang dipertahankan
- Dark navy / glass panels.
- Aksen neon cyan dan purple.
- Branding XylenMC dengan logo X.
- Typography Orbitron, Space Grotesk, dan JetBrains Mono.
- Dashboard, Enchantment Builder, Server Assistant, dan Settings.

## Fitur overlay pada source
- Floating X button memakai Android WindowManager dan permission SYSTEM_ALERT_WINDOW.
- Tombol X dapat digeser; posisi disimpan.
- Panel HUD native Compose dapat dibuka/tutup di atas aplikasi lain.
- Builder menyimpan pilihan build secara lokal, termasuk kategori, item, enchantment, level, dan ringkasan.
- Settings dan Server Assistant berada di aplikasi native.

## Batasan fungsional yang jujur
Overlay tidak membaca atau menulis inventory Minecraft, tidak mengubah item secara langsung, tidak mengirim command ke server, dan tidak melewati permission/anti-cheat. Fitur Builder di overlay adalah planner/preset lokal. Integrasi ke game memerlukan jalur resmi yang didukung world/server.

## Build APK via GitHub Actions
Workflow `.github/workflows/build-android.yml` sekarang membangun source langsung dari repository (tidak memerlukan ZIP tambahan di root). Workflow akan:
1. Menyiapkan JDK 17 dan Android SDK Platform 36.
2. Menginstal Gradle 8.13.
3. Menjalankan unit test.
4. Menjalankan `:app:assembleDebug`.
5. Memverifikasi APK dan mengunggah artifact `XylenMC-Native-Overlay-debug-APK`.

Jalankan workflow dari tab **Actions → XylenMC Native Overlay APK → Run workflow**. APK debug akan tersedia di bagian Artifacts jika seluruh langkah build berhasil.

## Versi
- versionCode: 3
- versionName: 1.2-native-overlay
- minSdk: 24 (Android 7.0+)
- compileSdk: 36
- targetSdk: 35
- JDK: 17

Catatan: source package ini sudah diperiksa struktur arsip dan konfigurasi workflow-nya. Build Android penuh belum dijalankan di lingkungan ini, jadi APK belum dinyatakan berhasil dikompilasi.
