# XylenMC Client Edition — Android Native Overlay

Ini adalah aplikasi Android native Kotlin + Jetpack Compose. Fitur overlay dibuat menggunakan `SYSTEM_ALERT_WINDOW`, `WindowManager` dan foreground service Android.

## Fitur yang benar-benar tersedia di build ini
- Aplikasi utama dengan halaman Enchantment Builder, Server Assistant, dan Settings.
- Tombol X mengambang di atas aplikasi lain setelah izin **Display over other apps** diberikan.
- Tombol dapat digeser; panel HUD dapat dibuka dan ditutup.
- Builder menyimpan pilihan item/enchantment secara lokal dan memeriksa kompatibilitas berdasarkan katalog lokal.
- Notifikasi foreground menyediakan kontrol untuk kembali ke aplikasi atau menghentikan overlay.

## Batasan penting
Overlay adalah pendamping/planner. Aplikasi ini **tidak** membaca atau mengubah inventaris Minecraft, tidak memasang enchantment ke item, tidak mengirim perintah ke server, dan tidak melewati izin/anti-cheat server. Untuk perubahan item nyata diperlukan Add-On/behavior pack atau izin/perintah dari server.

## Build lokal
- JDK 17
- Android SDK Platform 36
- Gradle 8.13

Jalankan `gradle :app:assembleDebug` atau `./gradlew :app:assembleDebug` jika wrapper lengkap tersedia. APK debug berada di `app/build/outputs/apk/debug/app-debug.apk`.

## Build GitHub Actions
Letakkan file workflow `build-xylenmc.yml` di `.github/workflows/` dan letakkan arsip proyek ini di root repository dengan nama `XylenMC_Native_Overlay_Source.zip`. Workflow akan mengekstrak source ke workspace sementara dan membangun APK debug.
