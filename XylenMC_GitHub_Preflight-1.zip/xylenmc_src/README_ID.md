# XylenMC Android — paket GitHub

Paket ini berisi source Android Kotlin + Jetpack Compose dan workflow GitHub Actions untuk menjalankan unit test serta membuat APK debug.

## Cara menggunakan GitHub melalui HP
1. Buat repository GitHub baru bernama `XylenMC-Android`.
2. Ekstrak ZIP ini di perangkat atau gunakan fitur upload file/folder GitHub jika tersedia. **Upload isi folder ini**, bukan folder pembungkus ZIP.
3. Pastikan `settings.gradle.kts`, `build.gradle.kts`, `gradle/`, `app/`, dan `.github/` berada langsung di root repository.
4. Buka tab **Actions**, pilih workflow **Build and test XylenMC Android**, lalu tekan **Run workflow**.
5. Tunggu sampai job hijau. Jika gagal, buka langkah yang merah dan salin log error untuk diperbaiki.
6. Jika berhasil, buka run tersebut, bagian **Artifacts**, lalu unduh `XylenMC-debug-apk`.

## Catatan validasi
- Workflow menjalankan `:app:testDebugUnitTest` sebelum `:app:assembleDebug`.
- Build menggunakan Android SDK 36, Build Tools 36.0.0, Java 21, dan Gradle 9.3.1.
- File ini belum boleh dianggap lulus kompilasi sebelum workflow GitHub Actions benar-benar selesai hijau.
- Aplikasi adalah companion UI/planner. Ia tidak dapat mengubah enchantment/inventaris pada server Minecraft pihak ketiga tanpa dukungan dan izin server.
