# XylenMC Android

Native Android companion app built with Kotlin and Jetpack Compose.

See [README_ID.md](README_ID.md) for GitHub Actions build instructions in Indonesian.
