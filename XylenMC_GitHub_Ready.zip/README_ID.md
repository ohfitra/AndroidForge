# XylenMC Client Edition — proyek Android

Proyek native Kotlin + Jetpack Compose untuk Android.

## Build APK debug di GitHub Actions
1. Letakkan seluruh isi folder proyek ini pada root repository (bukan ZIP sebagai satu file).
2. Simpan workflow `build-xylenmc.yml` pada `.github/workflows/build-xylenmc.yml`.
3. Buka tab Actions dan jalankan workflow **XylenMC Android APK**.
4. Unduh artifact `XylenMC-debug-apk` dari hasil run yang sukses.

Workflow mengompilasi `:app:assembleDebug` dan mengunggah APK debug. APK debug ditandatangani dengan debug key otomatis dan cocok untuk pengujian; bukan APK release Play Store.

## Catatan fungsi
Builder menyusun dan menyimpan konfigurasi enchantment secara lokal. Aplikasi tidak mengubah inventory atau enchantment pada server Minecraft pihak ketiga. Floating overlay meminta izin Android khusus sebelum dijalankan.
