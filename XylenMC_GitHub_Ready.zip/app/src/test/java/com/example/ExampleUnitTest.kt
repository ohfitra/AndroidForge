package com.example

import com.example.model.EnchantmentCatalog
import com.example.model.GearItem
import com.example.model.ItemCategory
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun allCategoriesHaveRequestedItems() {
    assertEquals(
      listOf(GearItem.HELMET, GearItem.CHESTPLATE, GearItem.LEGGINGS, GearItem.BOOTS, GearItem.ELYTRA),
      EnchantmentCatalog.itemsForCategory(ItemCategory.ARMOR),
    )
    assertEquals(
      listOf(
        GearItem.SWORD,
        GearItem.SPEAR,
        GearItem.MACE,
        GearItem.BOW,
        GearItem.CROSSBOW,
        GearItem.TRIDENT,
      ),
      EnchantmentCatalog.itemsForCategory(ItemCategory.WEAPONS),
    )
    assertEquals(
      listOf(
        GearItem.PICKAXE,
        GearItem.AXE,
        GearItem.SHOVEL,
        GearItem.HOE,
        GearItem.SHEARS,
        GearItem.FISHING_ROD,
        GearItem.BRUSH,
      ),
      EnchantmentCatalog.itemsForCategory(ItemCategory.TOOLS),
    )
    assertEquals(
      listOf(GearItem.SHIELD, GearItem.FLINT_AND_STEEL),
      EnchantmentCatalog.itemsForCategory(ItemCategory.UTILITY),
    )
  }

  @Test
  fun everyGearItemHasRelevantEnchantments() {
    GearItem.entries.forEach { item ->
      val enchants = EnchantmentCatalog.enchantmentsForItem(item)
      assertFalse("${item.displayName} should have enchantments", enchants.isEmpty())
    }
  }

  @Test
  fun detectsMutualExclusionsAndFormatsSummary() {
    val conflicts = EnchantmentCatalog.findConflicts(setOf("sharpness", "smite", "unbreaking"))
    assertEquals(1, conflicts.size)

    val summary =
      EnchantmentCatalog.formatBuildSummary(
        GearItem.MACE,
        mapOf("density" to 5, "wind_burst" to 3, "unbreaking" to 3),
      )
    assertTrue(summary.contains("Mace"))
    assertTrue(summary.contains("Density V"))
    assertTrue(summary.contains("Wind Burst III"))
    assertTrue(summary.contains("/enchant @s density 5"))
  }
}
