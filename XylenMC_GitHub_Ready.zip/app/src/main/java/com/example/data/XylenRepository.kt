package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.EnchantmentCatalog
import com.example.model.GearItem
import com.example.model.ItemCategory
import com.example.model.OverlayAnchorPreset
import com.example.model.ServerProfile
import com.example.model.XylenSettings
import com.example.model.XylenThemePreset
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

private val Context.xylenDataStore: DataStore<Preferences> by
  preferencesDataStore(name = "xylenmc_prefs")

class XylenRepository private constructor(private val appContext: Context) {

  private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
  private val dataStore = appContext.xylenDataStore

  private object Keys {
    val BUTTON_SIZE_DP = intPreferencesKey("button_size_dp")
    val OVERLAY_X = intPreferencesKey("overlay_x")
    val OVERLAY_Y = intPreferencesKey("overlay_y")
    val ANCHOR_PRESET = stringPreferencesKey("anchor_preset")
    val THEME_PRESET = stringPreferencesKey("theme_preset")
    val GLASS_OPACITY = floatPreferencesKey("glass_opacity")
    val GLOW_INTENSITY = floatPreferencesKey("glow_intensity")
    val AUTO_CHECK_CONFLICTS = booleanPreferencesKey("auto_check_conflicts")
    val SELECTED_ITEM = stringPreferencesKey("selected_item")
    val SELECTED_ENCHANTS = stringPreferencesKey("selected_enchants")
    val SERVER_PROFILE = stringPreferencesKey("server_profile")
  }

  private val _settings = MutableStateFlow(XylenSettings())
  val settings: StateFlow<XylenSettings> = _settings.asStateFlow()

  private val _selectedCategory = MutableStateFlow(ItemCategory.WEAPONS)
  val selectedCategory: StateFlow<ItemCategory> = _selectedCategory.asStateFlow()

  private val _selectedItem = MutableStateFlow(GearItem.SWORD)
  val selectedItem: StateFlow<GearItem> = _selectedItem.asStateFlow()

  private val _selectedEnchants =
    MutableStateFlow<Map<String, Int>>(
      mapOf("sharpness" to 5, "unbreaking" to 3, "mending" to 1)
    )
  val selectedEnchants: StateFlow<Map<String, Int>> = _selectedEnchants.asStateFlow()

  private val _isOverlayRunning = MutableStateFlow(false)
  val isOverlayRunning: StateFlow<Boolean> = _isOverlayRunning.asStateFlow()

  private val _isOverlayPanelExpanded = MutableStateFlow(false)
  val isOverlayPanelExpanded: StateFlow<Boolean> = _isOverlayPanelExpanded.asStateFlow()

  private val _selectedServerProfile = MutableStateFlow(ServerProfile.VANILLA_REALMS)
  val selectedServerProfile: StateFlow<ServerProfile> = _selectedServerProfile.asStateFlow()

  init {
    scope.launch {
      dataStore.data
        .map { prefs ->
          val anchorId = prefs[Keys.ANCHOR_PRESET]
          val anchor =
            OverlayAnchorPreset.entries.firstOrNull { it.id == anchorId }
              ?: OverlayAnchorPreset.MID_LEFT
          val themeId = prefs[Keys.THEME_PRESET]
          val theme =
            XylenThemePreset.entries.firstOrNull { it.id == themeId }
              ?: XylenThemePreset.CYBER_NEON
          XylenSettings(
            buttonSizeDp = (prefs[Keys.BUTTON_SIZE_DP] ?: 56).coerceIn(44, 84),
            overlayX = prefs[Keys.OVERLAY_X] ?: 28,
            overlayY = prefs[Keys.OVERLAY_Y] ?: 340,
            anchorPreset = anchor,
            themePreset = theme,
            glassOpacity = (prefs[Keys.GLASS_OPACITY] ?: 0.80f).coerceIn(0.45f, 0.95f),
            glowIntensity = (prefs[Keys.GLOW_INTENSITY] ?: 1.0f).coerceIn(0.3f, 1.4f),
            autoCheckConflicts = prefs[Keys.AUTO_CHECK_CONFLICTS] ?: true,
          )
        }
        .collect { loaded -> _settings.value = loaded }
    }

    scope.launch {
      dataStore.data.collect { prefs ->
        val itemId = prefs[Keys.SELECTED_ITEM]
        val item = GearItem.entries.firstOrNull { it.id == itemId }
        if (item != null) {
          _selectedItem.value = item
          _selectedCategory.value = item.category
        }

        val serializedEnchants = prefs[Keys.SELECTED_ENCHANTS]
        if (serializedEnchants != null) {
          val parsed = deserializeEnchants(serializedEnchants)
          _selectedEnchants.value = parsed
        }

        val profileId = prefs[Keys.SERVER_PROFILE]
        val profile = ServerProfile.entries.firstOrNull { it.id == profileId }
        if (profile != null) {
          _selectedServerProfile.value = profile
        }
      }
    }
  }

  fun selectCategory(category: ItemCategory) {
    _selectedCategory.value = category
    val current = _selectedItem.value
    if (current.category != category) {
      val firstInCategory = EnchantmentCatalog.itemsForCategory(category).firstOrNull() ?: return
      selectItem(firstInCategory)
    }
  }

  fun selectItem(item: GearItem) {
    _selectedCategory.value = item.category
    _selectedItem.value = item
    val validIds = EnchantmentCatalog.enchantmentsForItem(item).map { it.id }.toSet()
    val filtered = _selectedEnchants.value.filterKeys { it in validIds }
    _selectedEnchants.value = filtered
    persistBuild(item, filtered)
  }

  fun toggleEnchantment(enchantId: String) {
    val item = _selectedItem.value
    val def = EnchantmentCatalog.allEnchantments[enchantId] ?: return
    val currentMap = _selectedEnchants.value.toMutableMap()
    if (currentMap.containsKey(enchantId)) {
      currentMap.remove(enchantId)
    } else {
      currentMap[enchantId] = def.maxLevel
    }
    _selectedEnchants.value = currentMap
    persistBuild(item, currentMap)
  }

  fun setEnchantmentLevel(enchantId: String, level: Int) {
    val item = _selectedItem.value
    val def = EnchantmentCatalog.allEnchantments[enchantId] ?: return
    val clamped = level.coerceIn(1, def.maxLevel)
    val currentMap = _selectedEnchants.value.toMutableMap()
    currentMap[enchantId] = clamped
    _selectedEnchants.value = currentMap
    persistBuild(item, currentMap)
  }

  fun resetCurrentBuild() {
    _selectedEnchants.value = emptyMap()
    persistBuild(_selectedItem.value, emptyMap())
  }

  fun updateButtonSize(sizeDp: Int) {
    val clamped = sizeDp.coerceIn(44, 84)
    _settings.update { it.copy(buttonSizeDp = clamped) }
    scope.launch { dataStore.edit { it[Keys.BUTTON_SIZE_DP] = clamped } }
  }

  fun updateOverlayPosition(x: Int, y: Int) {
    _settings.update { it.copy(overlayX = x, overlayY = y) }
    scope.launch {
      dataStore.edit {
        it[Keys.OVERLAY_X] = x
        it[Keys.OVERLAY_Y] = y
      }
    }
  }

  fun applyAnchorPreset(preset: OverlayAnchorPreset, screenWidthPx: Int, screenHeightPx: Int) {
    val x = (screenWidthPx * preset.xFraction).toInt().coerceAtLeast(0)
    val y = (screenHeightPx * preset.yFraction).toInt().coerceAtLeast(48)
    _settings.update { it.copy(anchorPreset = preset, overlayX = x, overlayY = y) }
    scope.launch {
      dataStore.edit {
        it[Keys.ANCHOR_PRESET] = preset.id
        it[Keys.OVERLAY_X] = x
        it[Keys.OVERLAY_Y] = y
      }
    }
  }

  fun updateThemePreset(preset: XylenThemePreset) {
    _settings.update { it.copy(themePreset = preset) }
    scope.launch { dataStore.edit { it[Keys.THEME_PRESET] = preset.id } }
  }

  fun updateGlassOpacity(opacity: Float) {
    val clamped = opacity.coerceIn(0.45f, 0.95f)
    _settings.update { it.copy(glassOpacity = clamped) }
    scope.launch { dataStore.edit { it[Keys.GLASS_OPACITY] = clamped } }
  }

  fun updateGlowIntensity(intensity: Float) {
    val clamped = intensity.coerceIn(0.3f, 1.4f)
    _settings.update { it.copy(glowIntensity = clamped) }
    scope.launch { dataStore.edit { it[Keys.GLOW_INTENSITY] = clamped } }
  }

  fun updateAutoCheckConflicts(enabled: Boolean) {
    _settings.update { it.copy(autoCheckConflicts = enabled) }
    scope.launch { dataStore.edit { it[Keys.AUTO_CHECK_CONFLICTS] = enabled } }
  }

  fun setOverlayRunning(running: Boolean) {
    _isOverlayRunning.value = running
    if (!running) {
      _isOverlayPanelExpanded.value = false
    }
  }

  fun setOverlayPanelExpanded(expanded: Boolean) {
    _isOverlayPanelExpanded.value = expanded
  }

  fun selectServerProfile(profile: ServerProfile) {
    _selectedServerProfile.value = profile
    scope.launch { dataStore.edit { it[Keys.SERVER_PROFILE] = profile.id } }
  }

  private fun persistBuild(item: GearItem, enchants: Map<String, Int>) {
    scope.launch {
      dataStore.edit {
        it[Keys.SELECTED_ITEM] = item.id
        it[Keys.SELECTED_ENCHANTS] = serializeEnchants(enchants)
      }
    }
  }

  private fun serializeEnchants(enchants: Map<String, Int>): String =
    enchants.entries.joinToString(",") { "${it.key}:${it.value}" }

  private fun deserializeEnchants(raw: String): Map<String, Int> {
    if (raw.isBlank()) return emptyMap()
    return raw
      .split(",")
      .mapNotNull { entry ->
        val parts = entry.split(":")
        if (parts.size == 2) {
          val id = parts[0]
          val lvl = parts[1].toIntOrNull()
          if (lvl != null && EnchantmentCatalog.allEnchantments.containsKey(id)) {
            id to lvl
          } else {
            null
          }
        } else {
          null
        }
      }
      .toMap()
  }

  companion object {
    @Volatile private var instance: XylenRepository? = null

    fun getInstance(context: Context): XylenRepository {
      return instance
        ?: synchronized(this) {
          instance ?: XylenRepository(context.applicationContext).also { instance = it }
        }
    }
  }
}
