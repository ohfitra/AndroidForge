package com.example.model

enum class XylenThemePreset(
  val id: String,
  val label: String,
  val subtitle: String,
  val primaryHex: Long,
  val secondaryHex: Long,
  val tertiaryHex: Long,
) {
  CYBER_NEON(
    id = "cyber_neon",
    label = "Cyber Cyan & Purple",
    subtitle = "Signature dark navy with neon cyan and electric violet",
    primaryHex = 0xFF00F0FF,
    secondaryHex = 0xFF9D4EDD,
    tertiaryHex = 0xFF38BDF8,
  ),
  PLASMA_VIOLET(
    id = "plasma_violet",
    label = "Plasma Violet",
    subtitle = "Deep ultraviolet core with cyan edge accents",
    primaryHex = 0xFFC084FC,
    secondaryHex = 0xFF00E5FF,
    tertiaryHex = 0xFFF472B6,
  ),
  CRYO_MATRIX(
    id = "cryo_matrix",
    label = "Cryo Azure",
    subtitle = "Glacial neon cyan paired with cobalt indigo",
    primaryHex = 0xFF22D3EE,
    secondaryHex = 0xFF6366F1,
    tertiaryHex = 0xFF34D399,
  ),
  SOLAR_PULSE(
    id = "solar_pulse",
    label = "Hyper Pulse",
    subtitle = "Electric cyan & radiant neon magenta-amber",
    primaryHex = 0xFF00F0FF,
    secondaryHex = 0xFFE879F9,
    tertiaryHex = 0xFFFBBF24,
  ),
}

enum class OverlayAnchorPreset(
  val id: String,
  val label: String,
  val xFraction: Float,
  val yFraction: Float,
) {
  TOP_LEFT("top_left", "Top Left", 0.04f, 0.14f),
  TOP_RIGHT("top_right", "Top Right", 0.82f, 0.14f),
  MID_LEFT("mid_left", "Mid Left", 0.04f, 0.42f),
  MID_RIGHT("mid_right", "Mid Right", 0.82f, 0.42f),
  BOTTOM_LEFT("bottom_left", "Bottom Left", 0.04f, 0.74f),
  BOTTOM_RIGHT("bottom_right", "Bottom Right", 0.82f, 0.74f),
}

enum class FloatingButtonSize(val label: String, val sizeDp: Int) {
  SMALL("Small", 46),
  MEDIUM("Medium", 56),
  LARGE("Large", 68),
  XL("XL", 80),
}

data class XylenSettings(
  val buttonSizeDp: Int = 56,
  val overlayX: Int = 28,
  val overlayY: Int = 340,
  val anchorPreset: OverlayAnchorPreset = OverlayAnchorPreset.MID_LEFT,
  val themePreset: XylenThemePreset = XylenThemePreset.CYBER_NEON,
  val glassOpacity: Float = 0.80f,
  val glowIntensity: Float = 1.0f,
  val autoCheckConflicts: Boolean = true,
)

enum class ServerProfile(
  val id: String,
  val title: String,
  val badge: String,
  val subtitle: String,
  val allowsConflicts: Boolean,
  val allowsTreasure: Boolean,
  val allowsCurses: Boolean,
  val allowsExperimentalSpear: Boolean,
  val enforcementNote: String,
) {
  VANILLA_REALMS(
    id = "vanilla_realms",
    title = "Minecraft Realms / Vanilla",
    badge = "SURVIVAL RULES",
    subtitle = "Standard Bedrock Enchanting Table, Anvil & Villager rules.",
    allowsConflicts = false,
    allowsTreasure = true,
    allowsCurses = true,
    allowsExperimentalSpear = false,
    enforcementNote =
      "Realms validate enchantments server-side. Mutual exclusions cannot be combined on an Anvil in survival.",
  ),
  FEATURED_SERVERS(
    id = "featured_servers",
    title = "Featured Servers",
    badge = "STRICT ANTI-CHEAT",
    subtitle = "Public mini-game networks (kit-controlled inventories).",
    allowsConflicts = false,
    allowsTreasure = false,
    allowsCurses = false,
    allowsExperimentalSpear = false,
    enforcementNote =
      "Featured servers assign gear server-side per mini-game. Local builds act strictly as reference planning.",
  ),
  PRIVATE_SMP(
    id = "private_smp",
    title = "Private BDS / SMP Server",
    badge = "CONFIGURABLE",
    subtitle = "Dedicated Bedrock servers with optional behavior packs.",
    allowsConflicts = false,
    allowsTreasure = true,
    allowsCurses = true,
    allowsExperimentalSpear = true,
    enforcementNote =
      "Custom weapons like Spear or modified enchantment caps require server-side addons or operator commands.",
  ),
  CREATIVE_OPERATOR(
    id = "creative_operator",
    title = "Creative / Operator Sandbox",
    badge = "AUTHORIZED OP",
    subtitle = "Local worlds or servers where you hold operator permissions.",
    allowsConflicts = true,
    allowsTreasure = true,
    allowsCurses = true,
    allowsExperimentalSpear = true,
    enforcementNote =
      "With operator privileges, `/enchant` commands are validated by the server when executed in chat.",
  ),
}
