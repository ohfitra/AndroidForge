package com.example.model

enum class ItemCategory(val label: String, val tagline: String) {
  ARMOR("Armor", "Protective gear & flight"),
  WEAPONS("Weapons", "Melee, ranged & heavy impact"),
  TOOLS("Tools", "Harvesting, utility & crafting"),
  UTILITY("Utility", "Defense & survival essentials"),
}

enum class GearItem(
  val id: String,
  val displayName: String,
  val bedrockId: String,
  val category: ItemCategory,
  val summary: String,
  val compatibilityNote: String? = null,
) {
  // Armor
  HELMET(
    id = "helmet",
    displayName = "Helmet",
    bedrockId = "minecraft:netherite_helmet",
    category = ItemCategory.ARMOR,
    summary = "Head protection, underwater breathing & mining speed.",
  ),
  CHESTPLATE(
    id = "chestplate",
    displayName = "Chestplate",
    bedrockId = "minecraft:netherite_chestplate",
    category = ItemCategory.ARMOR,
    summary = "Core torso defense & thorns retaliation.",
  ),
  LEGGINGS(
    id = "leggings",
    displayName = "Leggings",
    bedrockId = "minecraft:netherite_leggings",
    category = ItemCategory.ARMOR,
    summary = "Lower-body armor with Swift Sneak stealth mobility.",
  ),
  BOOTS(
    id = "boots",
    displayName = "Boots",
    bedrockId = "minecraft:netherite_boots",
    category = ItemCategory.ARMOR,
    summary = "Fall mitigation, water striding & soul soil speed.",
  ),
  ELYTRA(
    id = "elytra",
    displayName = "Elytra",
    bedrockId = "minecraft:elytra",
    category = ItemCategory.ARMOR,
    summary = "End-game glide wings optimized for flight durability.",
  ),

  // Weapons
  SWORD(
    id = "sword",
    displayName = "Sword",
    bedrockId = "minecraft:netherite_sword",
    category = ItemCategory.WEAPONS,
    summary = "Fast melee strikes with looting & knockback control.",
  ),
  SPEAR(
    id = "spear",
    displayName = "Spear",
    bedrockId = "minecraft:spear",
    category = ItemCategory.WEAPONS,
    summary = "Long-reach thrust weapon for precision melee builds.",
    compatibilityNote =
      "Spear support & accepted enchantments depend on the Bedrock version or server behavior pack.",
  ),
  MACE(
    id = "mace",
    displayName = "Mace",
    bedrockId = "minecraft:mace",
    category = ItemCategory.WEAPONS,
    summary = "Smash-attack heavy weapon with Density, Breach & Wind Burst.",
  ),
  BOW(
    id = "bow",
    displayName = "Bow",
    bedrockId = "minecraft:bow",
    category = ItemCategory.WEAPONS,
    summary = "Long-range precision bow with flame & infinite arrows.",
  ),
  CROSSBOW(
    id = "crossbow",
    displayName = "Crossbow",
    bedrockId = "minecraft:crossbow",
    category = ItemCategory.WEAPONS,
    summary = "Pre-loaded burst launcher with Multishot or Piercing.",
  ),
  TRIDENT(
    id = "trident",
    displayName = "Trident",
    bedrockId = "minecraft:trident",
    category = ItemCategory.WEAPONS,
    summary = "Aquatic thrown & melee weapon with Loyalty or Riptide.",
  ),

  // Tools
  PICKAXE(
    id = "pickaxe",
    displayName = "Pickaxe",
    bedrockId = "minecraft:netherite_pickaxe",
    category = ItemCategory.TOOLS,
    summary = "Ore & stone mining with Fortune or Silk Touch.",
  ),
  AXE(
    id = "axe",
    displayName = "Axe",
    bedrockId = "minecraft:netherite_axe",
    category = ItemCategory.TOOLS,
    summary = "Timber harvesting & heavy melee damage hybrid.",
  ),
  SHOVEL(
    id = "shovel",
    displayName = "Shovel",
    bedrockId = "minecraft:netherite_shovel",
    category = ItemCategory.TOOLS,
    summary = "Rapid excavation for dirt, sand, gravel & snow.",
  ),
  HOE(
    id = "hoe",
    displayName = "Hoe",
    bedrockId = "minecraft:netherite_hoe",
    category = ItemCategory.TOOLS,
    summary = "Crop, sculk & leaf harvesting tool.",
  ),
  SHEARS(
    id = "shears",
    displayName = "Shears",
    bedrockId = "minecraft:shears",
    category = ItemCategory.TOOLS,
    summary = "Wool, leaves & cobweb precision harvester.",
  ),
  FISHING_ROD(
    id = "fishing_rod",
    displayName = "Fishing Rod",
    bedrockId = "minecraft:fishing_rod",
    category = ItemCategory.TOOLS,
    summary = "Treasure fishing & fast catch utility rod.",
  ),
  BRUSH(
    id = "brush",
    displayName = "Brush",
    bedrockId = "minecraft:brush",
    category = ItemCategory.TOOLS,
    summary = "Archaeology excavation tool for suspicious sand & gravel.",
  ),

  // Utility
  SHIELD(
    id = "shield",
    displayName = "Shield",
    bedrockId = "minecraft:shield",
    category = ItemCategory.UTILITY,
    summary = "Directional damage & projectile blocker.",
  ),
  FLINT_AND_STEEL(
    id = "flint_and_steel",
    displayName = "Flint and Steel",
    bedrockId = "minecraft:flint_and_steel",
    category = ItemCategory.UTILITY,
    summary = "Portal ignition & tactical fire starter.",
  ),
}

enum class EnchantmentType(val label: String) {
  PROTECTION("Protection"),
  COMBAT("Combat"),
  UTILITY("Utility"),
  DURABILITY("Durability"),
  TREASURE("Treasure"),
  CURSE("Curse"),
}

data class EnchantmentDef(
  val id: String,
  val bedrockId: String,
  val name: String,
  val maxLevel: Int,
  val type: EnchantmentType,
  val description: String,
  val incompatibleWith: Set<String> = emptySet(),
  val treasureOnly: Boolean = false,
)

data class EnchantmentConflict(
  val firstId: String,
  val secondId: String,
  val message: String,
)

object EnchantmentCatalog {

  val allEnchantments: Map<String, EnchantmentDef> =
    listOf(
        // Armor Protection
        EnchantmentDef(
          id = "protection",
          bedrockId = "protection",
          name = "Protection",
          maxLevel = 4,
          type = EnchantmentType.PROTECTION,
          description = "Reduces most incoming damage types.",
          incompatibleWith = setOf("fire_protection", "blast_protection", "projectile_protection"),
        ),
        EnchantmentDef(
          id = "fire_protection",
          bedrockId = "fire_protection",
          name = "Fire Protection",
          maxLevel = 4,
          type = EnchantmentType.PROTECTION,
          description = "Reduces fire & lava damage and burn time.",
          incompatibleWith = setOf("protection", "blast_protection", "projectile_protection"),
        ),
        EnchantmentDef(
          id = "blast_protection",
          bedrockId = "blast_protection",
          name = "Blast Protection",
          maxLevel = 4,
          type = EnchantmentType.PROTECTION,
          description = "Reduces explosion damage & knockback.",
          incompatibleWith = setOf("protection", "fire_protection", "projectile_protection"),
        ),
        EnchantmentDef(
          id = "projectile_protection",
          bedrockId = "projectile_protection",
          name = "Projectile Protection",
          maxLevel = 4,
          type = EnchantmentType.PROTECTION,
          description = "Reduces arrow, trident & fireball damage.",
          incompatibleWith = setOf("protection", "fire_protection", "blast_protection"),
        ),
        EnchantmentDef(
          id = "thorns",
          bedrockId = "thorns",
          name = "Thorns",
          maxLevel = 3,
          type = EnchantmentType.COMBAT,
          description = "Reflects melee & ranged damage back to attackers.",
        ),
        EnchantmentDef(
          id = "respiration",
          bedrockId = "respiration",
          name = "Respiration",
          maxLevel = 3,
          type = EnchantmentType.UTILITY,
          description = "Extends underwater breathing & improves underwater vision.",
        ),
        EnchantmentDef(
          id = "aqua_affinity",
          bedrockId = "aqua_affinity",
          name = "Aqua Affinity",
          maxLevel = 1,
          type = EnchantmentType.UTILITY,
          description = "Removes underwater mining speed penalty.",
        ),
        EnchantmentDef(
          id = "swift_sneak",
          bedrockId = "swift_sneak",
          name = "Swift Sneak",
          maxLevel = 3,
          type = EnchantmentType.TREASURE,
          description = "Increases movement speed while crouching.",
          treasureOnly = true,
        ),
        EnchantmentDef(
          id = "feather_falling",
          bedrockId = "feather_falling",
          name = "Feather Falling",
          maxLevel = 4,
          type = EnchantmentType.PROTECTION,
          description = "Reduces fall & Ender Pearl teleport damage.",
        ),
        EnchantmentDef(
          id = "depth_strider",
          bedrockId = "depth_strider",
          name = "Depth Strider",
          maxLevel = 3,
          type = EnchantmentType.UTILITY,
          description = "Increases underwater swimming speed.",
          incompatibleWith = setOf("frost_walker"),
        ),
        EnchantmentDef(
          id = "frost_walker",
          bedrockId = "frost_walker",
          name = "Frost Walker",
          maxLevel = 2,
          type = EnchantmentType.TREASURE,
          description = "Turns water beneath feet into frosted ice.",
          incompatibleWith = setOf("depth_strider"),
          treasureOnly = true,
        ),
        EnchantmentDef(
          id = "soul_speed",
          bedrockId = "soul_speed",
          name = "Soul Speed",
          maxLevel = 3,
          type = EnchantmentType.TREASURE,
          description = "Boosts speed on Soul Sand and Soul Soil.",
          treasureOnly = true,
        ),

        // Melee & Mace
        EnchantmentDef(
          id = "sharpness",
          bedrockId = "sharpness",
          name = "Sharpness",
          maxLevel = 5,
          type = EnchantmentType.COMBAT,
          description = "Increases base melee damage against all targets.",
          incompatibleWith = setOf("smite", "bane_of_arthropods"),
        ),
        EnchantmentDef(
          id = "smite",
          bedrockId = "smite",
          name = "Smite",
          maxLevel = 5,
          type = EnchantmentType.COMBAT,
          description = "Deals heavy bonus damage to undead mobs.",
          incompatibleWith = setOf("sharpness", "bane_of_arthropods", "density", "breach"),
        ),
        EnchantmentDef(
          id = "bane_of_arthropods",
          bedrockId = "bane_of_arthropods",
          name = "Bane of Arthropods",
          maxLevel = 5,
          type = EnchantmentType.COMBAT,
          description = "Deals bonus damage & slowness to spiders and arthropods.",
          incompatibleWith = setOf("sharpness", "smite", "density", "breach"),
        ),
        EnchantmentDef(
          id = "knockback",
          bedrockId = "knockback",
          name = "Knockback",
          maxLevel = 2,
          type = EnchantmentType.COMBAT,
          description = "Pushes targets backward on melee hits.",
        ),
        EnchantmentDef(
          id = "fire_aspect",
          bedrockId = "fire_aspect",
          name = "Fire Aspect",
          maxLevel = 2,
          type = EnchantmentType.COMBAT,
          description = "Ignites targets on melee strike.",
        ),
        EnchantmentDef(
          id = "looting",
          bedrockId = "looting",
          name = "Looting",
          maxLevel = 3,
          type = EnchantmentType.UTILITY,
          description = "Increases mob item drops & rare loot chances.",
        ),
        EnchantmentDef(
          id = "density",
          bedrockId = "density",
          name = "Density",
          maxLevel = 5,
          type = EnchantmentType.COMBAT,
          description = "Amplifies Mace smash damage per block fallen.",
          incompatibleWith = setOf("breach", "smite", "bane_of_arthropods"),
        ),
        EnchantmentDef(
          id = "breach",
          bedrockId = "breach",
          name = "Breach",
          maxLevel = 4,
          type = EnchantmentType.COMBAT,
          description = "Reduces target armor effectiveness on Mace strikes.",
          incompatibleWith = setOf("density", "smite", "bane_of_arthropods"),
        ),
        EnchantmentDef(
          id = "wind_burst",
          bedrockId = "wind_burst",
          name = "Wind Burst",
          maxLevel = 3,
          type = EnchantmentType.TREASURE,
          description = "Launches wielder upward after a successful Mace smash.",
          treasureOnly = true,
        ),

        // Ranged & Trident
        EnchantmentDef(
          id = "power",
          bedrockId = "power",
          name = "Power",
          maxLevel = 5,
          type = EnchantmentType.COMBAT,
          description = "Increases arrow damage.",
        ),
        EnchantmentDef(
          id = "punch",
          bedrockId = "punch",
          name = "Punch",
          maxLevel = 2,
          type = EnchantmentType.COMBAT,
          description = "Increases arrow knockback distance.",
        ),
        EnchantmentDef(
          id = "flame",
          bedrockId = "flame",
          name = "Flame",
          maxLevel = 1,
          type = EnchantmentType.COMBAT,
          description = "Fires flaming arrows that ignite targets & TNT.",
        ),
        EnchantmentDef(
          id = "infinity",
          bedrockId = "infinity",
          name = "Infinity",
          maxLevel = 1,
          type = EnchantmentType.UTILITY,
          description = "Shooting consumes no regular arrows while at least one is held.",
          incompatibleWith = setOf("mending"),
        ),
        EnchantmentDef(
          id = "quick_charge",
          bedrockId = "quick_charge",
          name = "Quick Charge",
          maxLevel = 3,
          type = EnchantmentType.UTILITY,
          description = "Decreases Crossbow reload duration.",
        ),
        EnchantmentDef(
          id = "multishot",
          bedrockId = "multishot",
          name = "Multishot",
          maxLevel = 1,
          type = EnchantmentType.COMBAT,
          description = "Fires 3 arrows or rockets for the cost of 1.",
          incompatibleWith = setOf("piercing"),
        ),
        EnchantmentDef(
          id = "piercing",
          bedrockId = "piercing",
          name = "Piercing",
          maxLevel = 4,
          type = EnchantmentType.COMBAT,
          description = "Arrows pass through multiple entities & shields.",
          incompatibleWith = setOf("multishot"),
        ),
        EnchantmentDef(
          id = "impaling",
          bedrockId = "impaling",
          name = "Impaling",
          maxLevel = 5,
          type = EnchantmentType.COMBAT,
          description = "Deals extra damage to aquatic targets & targets in water/rain (Bedrock).",
        ),
        EnchantmentDef(
          id = "loyalty",
          bedrockId = "loyalty",
          name = "Loyalty",
          maxLevel = 3,
          type = EnchantmentType.UTILITY,
          description = "Returns thrown Trident automatically to owner.",
          incompatibleWith = setOf("riptide"),
        ),
        EnchantmentDef(
          id = "channeling",
          bedrockId = "channeling",
          name = "Channeling",
          maxLevel = 1,
          type = EnchantmentType.COMBAT,
          description = "Summons lightning on hit during thunderstorms.",
          incompatibleWith = setOf("riptide"),
        ),
        EnchantmentDef(
          id = "riptide",
          bedrockId = "riptide",
          name = "Riptide",
          maxLevel = 3,
          type = EnchantmentType.UTILITY,
          description = "Propels player forward when throwing Trident in water or rain.",
          incompatibleWith = setOf("loyalty", "channeling"),
        ),

        // Tools & Fishing
        EnchantmentDef(
          id = "efficiency",
          bedrockId = "efficiency",
          name = "Efficiency",
          maxLevel = 5,
          type = EnchantmentType.UTILITY,
          description = "Increases block breaking speed.",
        ),
        EnchantmentDef(
          id = "fortune",
          bedrockId = "fortune",
          name = "Fortune",
          maxLevel = 3,
          type = EnchantmentType.UTILITY,
          description = "Increases ore, crop & gravel drop yields.",
          incompatibleWith = setOf("silk_touch"),
        ),
        EnchantmentDef(
          id = "silk_touch",
          bedrockId = "silk_touch",
          name = "Silk Touch",
          maxLevel = 1,
          type = EnchantmentType.UTILITY,
          description = "Mined blocks drop themselves instead of resources.",
          incompatibleWith = setOf("fortune"),
        ),
        EnchantmentDef(
          id = "luck_of_the_sea",
          bedrockId = "luck_of_the_sea",
          name = "Luck of the Sea",
          maxLevel = 3,
          type = EnchantmentType.UTILITY,
          description = "Increases treasure catch odds while fishing.",
        ),
        EnchantmentDef(
          id = "lure",
          bedrockId = "lure",
          name = "Lure",
          maxLevel = 3,
          type = EnchantmentType.UTILITY,
          description = "Reduces wait time until fish bite.",
        ),

        // Universal Durability & Curses
        EnchantmentDef(
          id = "unbreaking",
          bedrockId = "unbreaking",
          name = "Unbreaking",
          maxLevel = 3,
          type = EnchantmentType.DURABILITY,
          description = "Chance to avoid durability loss on use.",
        ),
        EnchantmentDef(
          id = "mending",
          bedrockId = "mending",
          name = "Mending",
          maxLevel = 1,
          type = EnchantmentType.TREASURE,
          description = "Repairs item durability using collected XP orbs.",
          incompatibleWith = setOf("infinity"),
          treasureOnly = true,
        ),
        EnchantmentDef(
          id = "binding_curse",
          bedrockId = "binding",
          name = "Curse of Binding",
          maxLevel = 1,
          type = EnchantmentType.CURSE,
          description = "Prevents removing equipped armor until death or breakage.",
          treasureOnly = true,
        ),
        EnchantmentDef(
          id = "vanishing_curse",
          bedrockId = "vanishing",
          name = "Curse of Vanishing",
          maxLevel = 1,
          type = EnchantmentType.CURSE,
          description = "Destroys item upon player death instead of dropping it.",
          treasureOnly = true,
        ),
      )
      .associateBy { it.id }

  private val itemEnchantmentIds: Map<GearItem, List<String>> =
    mapOf(
      GearItem.HELMET to
        listOf(
          "protection",
          "fire_protection",
          "blast_protection",
          "projectile_protection",
          "respiration",
          "aqua_affinity",
          "thorns",
          "unbreaking",
          "mending",
          "binding_curse",
          "vanishing_curse",
        ),
      GearItem.CHESTPLATE to
        listOf(
          "protection",
          "fire_protection",
          "blast_protection",
          "projectile_protection",
          "thorns",
          "unbreaking",
          "mending",
          "binding_curse",
          "vanishing_curse",
        ),
      GearItem.LEGGINGS to
        listOf(
          "protection",
          "fire_protection",
          "blast_protection",
          "projectile_protection",
          "swift_sneak",
          "thorns",
          "unbreaking",
          "mending",
          "binding_curse",
          "vanishing_curse",
        ),
      GearItem.BOOTS to
        listOf(
          "protection",
          "fire_protection",
          "blast_protection",
          "projectile_protection",
          "feather_falling",
          "depth_strider",
          "frost_walker",
          "soul_speed",
          "thorns",
          "unbreaking",
          "mending",
          "binding_curse",
          "vanishing_curse",
        ),
      GearItem.ELYTRA to listOf("unbreaking", "mending", "binding_curse", "vanishing_curse"),
      GearItem.SWORD to
        listOf(
          "sharpness",
          "smite",
          "bane_of_arthropods",
          "knockback",
          "fire_aspect",
          "looting",
          "unbreaking",
          "mending",
          "vanishing_curse",
        ),
      GearItem.SPEAR to
        listOf(
          "sharpness",
          "smite",
          "bane_of_arthropods",
          "impaling",
          "knockback",
          "fire_aspect",
          "looting",
          "unbreaking",
          "mending",
          "vanishing_curse",
        ),
      GearItem.MACE to
        listOf(
          "density",
          "breach",
          "wind_burst",
          "smite",
          "bane_of_arthropods",
          "fire_aspect",
          "unbreaking",
          "mending",
          "vanishing_curse",
        ),
      GearItem.BOW to
        listOf("power", "punch", "flame", "infinity", "unbreaking", "mending", "vanishing_curse"),
      GearItem.CROSSBOW to
        listOf("quick_charge", "multishot", "piercing", "unbreaking", "mending", "vanishing_curse"),
      GearItem.TRIDENT to
        listOf(
          "impaling",
          "loyalty",
          "channeling",
          "riptide",
          "unbreaking",
          "mending",
          "vanishing_curse",
        ),
      GearItem.PICKAXE to
        listOf("efficiency", "fortune", "silk_touch", "unbreaking", "mending", "vanishing_curse"),
      GearItem.AXE to
        listOf(
          "efficiency",
          "sharpness",
          "smite",
          "bane_of_arthropods",
          "fortune",
          "silk_touch",
          "unbreaking",
          "mending",
          "vanishing_curse",
        ),
      GearItem.SHOVEL to
        listOf("efficiency", "fortune", "silk_touch", "unbreaking", "mending", "vanishing_curse"),
      GearItem.HOE to
        listOf("efficiency", "fortune", "silk_touch", "unbreaking", "mending", "vanishing_curse"),
      GearItem.SHEARS to listOf("efficiency", "unbreaking", "mending", "vanishing_curse"),
      GearItem.FISHING_ROD to
        listOf("luck_of_the_sea", "lure", "unbreaking", "mending", "vanishing_curse"),
      GearItem.BRUSH to listOf("unbreaking", "mending", "vanishing_curse"),
      GearItem.SHIELD to listOf("unbreaking", "mending", "vanishing_curse"),
      GearItem.FLINT_AND_STEEL to listOf("unbreaking", "mending", "vanishing_curse"),
    )

  fun itemsForCategory(category: ItemCategory): List<GearItem> =
    GearItem.entries.filter { it.category == category }

  fun enchantmentsForItem(item: GearItem): List<EnchantmentDef> =
    itemEnchantmentIds[item].orEmpty().mapNotNull { allEnchantments[it] }

  fun findConflicts(selectedIds: Set<String>): List<EnchantmentConflict> {
    val ordered = selectedIds.toList()
    val conflicts = mutableListOf<EnchantmentConflict>()
    for (i in ordered.indices) {
      val first = allEnchantments[ordered[i]] ?: continue
      for (j in i + 1 until ordered.size) {
        val second = allEnchantments[ordered[j]] ?: continue
        if (first.incompatibleWith.contains(second.id) || second.incompatibleWith.contains(first.id)) {
          conflicts.add(
            EnchantmentConflict(
              firstId = first.id,
              secondId = second.id,
              message = "${first.name} is incompatible with ${second.name} in standard survival.",
            )
          )
        }
      }
    }
    return conflicts
  }

  fun toRoman(level: Int): String =
    when (level) {
      1 -> "I"
      2 -> "II"
      3 -> "III"
      4 -> "IV"
      5 -> "V"
      else -> level.toString()
    }

  fun formatBuildSummary(item: GearItem, selectedEnchants: Map<String, Int>): String {
    val validOrdered =
      enchantmentsForItem(item).mapNotNull { def ->
        selectedEnchants[def.id]?.let { lvl -> def to lvl.coerceIn(1, def.maxLevel) }
      }
    val conflicts = findConflicts(validOrdered.map { it.first.id }.toSet())
    val builder = StringBuilder()
    builder.appendLine("XYLENMC CLIENT EDITION // LOCAL BUILD PLAN")
    builder.appendLine("Category: ${item.category.label}")
    builder.appendLine("Item: ${item.displayName} (${item.bedrockId})")
    if (validOrdered.isEmpty()) {
      builder.appendLine("Enchantments: None selected")
    } else {
      builder.appendLine("Enchantments (${validOrdered.size}):")
      validOrdered.forEach { (def, lvl) ->
        builder.appendLine("• ${def.name} ${toRoman(lvl)}")
      }
      builder.appendLine()
      builder.appendLine("Bedrock Operator / Creative Reference:")
      builder.appendLine("/give @s ${item.bedrockId} 1")
      validOrdered.forEach { (def, lvl) ->
        builder.appendLine("/enchant @s ${def.bedrockId} $lvl")
      }
    }
    if (conflicts.isNotEmpty()) {
      builder.appendLine()
      builder.appendLine("Compatibility Notes:")
      conflicts.forEach { builder.appendLine("! ${it.message}") }
    }
    return builder.toString().trim()
  }

  fun formatCommandLines(item: GearItem, selectedEnchants: Map<String, Int>): List<String> {
    val validOrdered =
      enchantmentsForItem(item).mapNotNull { def ->
        selectedEnchants[def.id]?.let { lvl -> def to lvl.coerceIn(1, def.maxLevel) }
      }
    if (validOrdered.isEmpty()) return emptyList()
    return listOf("/give @s ${item.bedrockId} 1") +
      validOrdered.map { (def, lvl) -> "/enchant @s ${def.bedrockId} $lvl" }
  }
}
