package com.example.overlay

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.ContextCompat

object OverlayController {

  fun canDrawOverlays(context: Context): Boolean {
    return Settings.canDrawOverlays(context)
  }

  fun openOverlayPermissionSettings(context: Context) {
    val intent =
      Intent(
        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
        Uri.parse("package:${context.packageName}"),
      ).apply {
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      }
    context.startActivity(intent)
  }

  fun startOverlayService(context: Context) {
    if (!canDrawOverlays(context)) {
      openOverlayPermissionSettings(context)
      return
    }
    val intent =
      Intent(context, OverlayService::class.java).apply {
        action = OverlayService.ACTION_START
      }
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      ContextCompat.startForegroundService(context, intent)
    } else {
      context.startService(intent)
    }
  }

  fun stopOverlayService(context: Context) {
    val intent =
      Intent(context, OverlayService::class.java).apply {
        action = OverlayService.ACTION_STOP
      }
    context.startService(intent)
  }

  fun toggleOverlayService(context: Context, currentlyRunning: Boolean) {
    if (currentlyRunning) {
      stopOverlayService(context)
    } else {
      startOverlayService(context)
    }
  }
}
