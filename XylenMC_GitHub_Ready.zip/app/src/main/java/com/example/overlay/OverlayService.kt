package com.example.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.ComposeView
import androidx.core.app.NotificationCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.example.MainActivity
import com.example.R
import com.example.data.XylenRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

class OverlayService :
  Service(), LifecycleOwner, SavedStateRegistryOwner, ViewModelStoreOwner {

  private val lifecycleRegistry = LifecycleRegistry(this)
  private val savedStateController = SavedStateRegistryController.create(this)
  private val store = ViewModelStore()

  override val lifecycle: Lifecycle
    get() = lifecycleRegistry

  override val savedStateRegistry: SavedStateRegistry
    get() = savedStateController.savedStateRegistry

  override val viewModelStore: ViewModelStore
    get() = store

  private lateinit var windowManager: WindowManager
  private lateinit var repo: XylenRepository
  private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

  private var bubbleView: ComposeView? = null
  private var bubbleParams: WindowManager.LayoutParams? = null
  private var panelView: ComposeView? = null

  private var dragFloatX = 0f
  private var dragFloatY = 0f

  override fun onCreate() {
    super.onCreate()
    savedStateController.performAttach()
    savedStateController.performRestore(null)
    lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)

    windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
    repo = XylenRepository.getInstance(this)

    createNotificationChannel()
    startForegroundOverlay()

    if (!Settings.canDrawOverlays(this)) {
      stopSelf()
      return
    }

    lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
    lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)

    attachFloatingBubble()
    observeOverlayState()
    repo.setOverlayRunning(true)
  }

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    when (intent?.action) {
      ACTION_STOP -> {
        stopSelf()
        return START_NOT_STICKY
      }
      ACTION_START,
      null -> {
        if (!Settings.canDrawOverlays(this)) {
          stopSelf()
          return START_NOT_STICKY
        }
        repo.setOverlayRunning(true)
      }
    }
    return START_STICKY
  }

  private fun startForegroundOverlay() {
    val notification = buildNotification()
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
      startForeground(
        NOTIFICATION_ID,
        notification,
        ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE,
      )
    } else {
      startForeground(NOTIFICATION_ID, notification)
    }
  }

  private fun createNotificationChannel() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val manager = getSystemService(NotificationManager::class.java)
      val channel =
        NotificationChannel(
            CHANNEL_ID,
            getString(R.string.overlay_channel_name),
            NotificationManager.IMPORTANCE_LOW,
          )
          .apply { description = getString(R.string.overlay_channel_desc) }
      manager.createNotificationChannel(channel)
    }
  }

  private fun buildNotification(): Notification {
    val openIntent =
      PendingIntent.getActivity(
        this,
        0,
        Intent(this, MainActivity::class.java).apply {
          addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        },
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
      )

    val stopIntent =
      PendingIntent.getService(
        this,
        1,
        Intent(this, OverlayService::class.java).apply { action = ACTION_STOP },
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
      )

    return NotificationCompat.Builder(this, CHANNEL_ID)
      .setSmallIcon(R.mipmap.ic_launcher)
      .setContentTitle(getString(R.string.overlay_notif_title))
      .setContentText(getString(R.string.overlay_notif_text))
      .setOngoing(true)
      .setContentIntent(openIntent)
      .addAction(0, getString(R.string.overlay_action_open), openIntent)
      .addAction(0, getString(R.string.overlay_action_stop), stopIntent)
      .build()
  }

  private fun overlayWindowType(): Int =
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    } else {
      @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
    }

  private fun attachFloatingBubble() {
    if (bubbleView != null) return
    val initialSettings = repo.settings.value
    val params =
      WindowManager.LayoutParams(
          WindowManager.LayoutParams.WRAP_CONTENT,
          WindowManager.LayoutParams.WRAP_CONTENT,
          overlayWindowType(),
          WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
          PixelFormat.TRANSLUCENT,
        )
        .apply {
          gravity = Gravity.TOP or Gravity.START
          x = initialSettings.overlayX
          y = initialSettings.overlayY
        }
    dragFloatX = params.x.toFloat()
    dragFloatY = params.y.toFloat()

    val view =
      ComposeView(this).apply {
        setViewTreeLifecycleOwner(this@OverlayService)
        setViewTreeSavedStateRegistryOwner(this@OverlayService)
        setViewTreeViewModelStoreOwner(this@OverlayService)
        setContent {
          val settings by repo.settings.collectAsState()
          val expanded by repo.isOverlayPanelExpanded.collectAsState()
          FloatingXBubble(
            settings = settings,
            isPanelExpanded = expanded,
            onTogglePanel = { repo.setOverlayPanelExpanded(!repo.isOverlayPanelExpanded.value) },
            onDragDelta = { dx, dy ->
              val metrics = resources.displayMetrics
              val maxX = (metrics.widthPixels - (settings.buttonSizeDp * metrics.density)).coerceAtLeast(0f)
              val maxY = (metrics.heightPixels - (settings.buttonSizeDp * metrics.density)).coerceAtLeast(0f)
              dragFloatX = (dragFloatX + dx).coerceIn(0f, maxX)
              dragFloatY = (dragFloatY + dy).coerceIn(0f, maxY)
              params.x = dragFloatX.roundToInt()
              params.y = dragFloatY.roundToInt()
              if (isAttachedToWindow) {
                windowManager.updateViewLayout(this, params)
              }
            },
            onDragEnd = { repo.updateOverlayPosition(params.x, params.y) },
          )
        }
      }

    bubbleParams = params
    bubbleView = view
    windowManager.addView(view, params)
  }

  private fun observeOverlayState() {
    serviceScope.launch {
      repo.isOverlayPanelExpanded.collect { expanded ->
        if (expanded) attachOverlayPanel() else detachOverlayPanel()
      }
    }
    serviceScope.launch {
      repo.settings
        .map { it.overlayX to it.overlayY }
        .distinctUntilChanged()
        .collect { (x, y) ->
          val params = bubbleParams ?: return@collect
          val view = bubbleView ?: return@collect
          if (params.x != x || params.y != y) {
            params.x = x
            params.y = y
            dragFloatX = x.toFloat()
            dragFloatY = y.toFloat()
            if (view.isAttachedToWindow) {
              windowManager.updateViewLayout(view, params)
            }
          }
        }
    }
  }

  private fun attachOverlayPanel() {
    if (panelView != null) return
    val params =
      WindowManager.LayoutParams(
          WindowManager.LayoutParams.WRAP_CONTENT,
          WindowManager.LayoutParams.WRAP_CONTENT,
          overlayWindowType(),
          WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
          PixelFormat.TRANSLUCENT,
        )
        .apply { gravity = Gravity.CENTER }

    val view =
      ComposeView(this).apply {
        setViewTreeLifecycleOwner(this@OverlayService)
        setViewTreeSavedStateRegistryOwner(this@OverlayService)
        setViewTreeViewModelStoreOwner(this@OverlayService)
        setContent {
          val settings by repo.settings.collectAsState()
          val category by repo.selectedCategory.collectAsState()
          val item by repo.selectedItem.collectAsState()
          val enchants by repo.selectedEnchants.collectAsState()
          OverlayHudPanel(
            settings = settings,
            selectedCategory = category,
            selectedItem = item,
            selectedEnchants = enchants,
            onSelectCategory = repo::selectCategory,
            onSelectItem = repo::selectItem,
            onToggleEnchant = repo::toggleEnchantment,
            onSetLevel = repo::setEnchantmentLevel,
            onReset = repo::resetCurrentBuild,
            onClosePanel = { repo.setOverlayPanelExpanded(false) },
            onOpenFullApp = {
              repo.setOverlayPanelExpanded(false)
              val intent =
                Intent(this@OverlayService, MainActivity::class.java).apply {
                  addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                }
              startActivity(intent)
            },
          )
        }
      }

    panelView = view
    windowManager.addView(view, params)
  }

  private fun detachOverlayPanel() {
    panelView?.let { view ->
      if (view.isAttachedToWindow) {
        windowManager.removeViewImmediate(view)
      }
    }
    panelView = null
  }

  override fun onDestroy() {
    super.onDestroy()
    repo.setOverlayRunning(false)
    serviceScope.cancel()
    detachOverlayPanel()
    bubbleView?.let { view ->
      if (view.isAttachedToWindow) {
        windowManager.removeViewImmediate(view)
      }
    }
    bubbleView = null
    lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_PAUSE)
    lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_STOP)
    lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
    store.clear()
  }

  override fun onBind(intent: Intent?): IBinder? = null

  companion object {
    const val ACTION_START = "com.example.overlay.ACTION_START"
    const val ACTION_STOP = "com.example.overlay.ACTION_STOP"
    private const val CHANNEL_ID = "xylenmc_overlay_channel"
    private const val NOTIFICATION_ID = 1042
  }
}
