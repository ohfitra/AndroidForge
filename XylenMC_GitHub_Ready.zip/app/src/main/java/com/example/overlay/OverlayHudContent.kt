package com.example.overlay

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.OpenInNew
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material.icons.rounded.RestartAlt
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.EnchantmentCatalog
import com.example.model.EnchantmentDef
import com.example.model.GearItem
import com.example.model.ItemCategory
import com.example.model.XylenSettings
import com.example.ui.components.GlassCard
import com.example.ui.components.NeonGradientButton
import com.example.ui.components.NeonOutlinedButton
import com.example.ui.components.XylenLogoMark
import com.example.ui.components.icon
import com.example.ui.theme.LocalXylenTokens
import com.example.ui.theme.NavyDeep
import com.example.ui.theme.NavySurface
import com.example.ui.theme.NavySurfaceElevated
import com.example.ui.theme.NavyVoid
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.XylenMCTheme

@Composable
fun FloatingXBubble(
  settings: XylenSettings,
  isPanelExpanded: Boolean,
  onTogglePanel: () -> Unit,
  onDragDelta: (dx: Float, dy: Float) -> Unit,
  onDragEnd: () -> Unit,
) {
  XylenMCTheme(settings = settings) {
    val tokens = LocalXylenTokens.current
    val desc = stringResource(R.string.cd_floating_x_button)
    val buttonSize = settings.buttonSizeDp.dp
    Box(
      modifier =
        Modifier.size(buttonSize)
          .clip(CircleShape)
          .background(
            brush =
              Brush.radialGradient(
                colors = listOf(NavySurfaceElevated.copy(alpha = 0.96f), NavyVoid.copy(alpha = 0.96f))
              )
          )
          .border(
            width = if (isPanelExpanded) 2.dp else 1.5.dp,
            brush = Brush.linearGradient(listOf(tokens.accentPrimary, tokens.accentSecondary)),
            shape = CircleShape,
          )
          .pointerInput(Unit) {
            detectDragGestures(
              onDragEnd = onDragEnd,
              onDragCancel = onDragEnd,
              onDrag = { change, dragAmount ->
                change.consume()
                onDragDelta(dragAmount.x, dragAmount.y)
              },
            )
          }
          .clickable(onClick = onTogglePanel)
          .semantics { contentDescription = desc }
          .testTag("floating_x_button"),
      contentAlignment = Alignment.Center,
    ) {
      XylenLogoMark(size = buttonSize * 0.72f, animatedGlow = isPanelExpanded)
    }
  }
}

@Composable
fun OverlayHudPanel(
  settings: XylenSettings,
  selectedCategory: ItemCategory,
  selectedItem: GearItem,
  selectedEnchants: Map<String, Int>,
  onSelectCategory: (ItemCategory) -> Unit,
  onSelectItem: (GearItem) -> Unit,
  onToggleEnchant: (String) -> Unit,
  onSetLevel: (String, Int) -> Unit,
  onReset: () -> Unit,
  onClosePanel: () -> Unit,
  onOpenFullApp: () -> Unit,
) {
  XylenMCTheme(settings = settings) {
    val tokens = LocalXylenTokens.current
    val context = LocalContext.current
    val itemsInCategory = EnchantmentCatalog.itemsForCategory(selectedCategory)
    val enchantments = EnchantmentCatalog.enchantmentsForItem(selectedItem)
    val validSelected =
      selectedEnchants.filterKeys { id -> enchantments.any { it.id == id } }
    val conflicts = EnchantmentCatalog.findConflicts(validSelected.keys)

    Surface(
      modifier =
        Modifier.width(340.dp)
          .heightIn(max = 530.dp)
          .border(
            width = 1.5.dp,
            brush = Brush.linearGradient(listOf(tokens.accentPrimary, tokens.accentSecondary)),
            shape = RoundedCornerShape(22.dp),
          ),
      shape = RoundedCornerShape(22.dp),
      color = NavyDeep.copy(alpha = 0.94f),
    ) {
      Column(modifier = Modifier.padding(14.dp)) {
        // Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            XylenLogoMark(size = 32.dp, animatedGlow = true)
            Spacer(Modifier.width(10.dp))
            Column {
              Text(
                text = "XYLENMC HUD",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
              )
              Text(
                text = "LOCAL OVERLAY PLANNER",
                style = MaterialTheme.typography.labelSmall,
                color = tokens.accentPrimary,
              )
            }
          }
          Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(
              onClick = onOpenFullApp,
              modifier = Modifier.size(40.dp).testTag("overlay_open_app_button"),
            ) {
              Icon(
                imageVector = Icons.Rounded.OpenInNew,
                contentDescription = stringResource(R.string.overlay_action_open),
                tint = tokens.accentPrimary,
                modifier = Modifier.size(20.dp),
              )
            }
            IconButton(
              onClick = onClosePanel,
              modifier = Modifier.size(40.dp).testTag("overlay_close_button"),
            ) {
              Icon(
                imageVector = Icons.Rounded.Close,
                contentDescription = stringResource(R.string.cd_close_overlay_panel),
                tint = TextSecondary,
                modifier = Modifier.size(20.dp),
              )
            }
          }
        }

        Spacer(Modifier.height(10.dp))

        // Category pills
        Row(
          modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          ItemCategory.entries.forEach { category ->
            val selected = category == selectedCategory
            Box(
              modifier =
                Modifier.clip(RoundedCornerShape(10.dp))
                  .background(
                    if (selected) tokens.accentPrimary.copy(alpha = 0.22f)
                    else NavySurface.copy(alpha = 0.85f)
                  )
                  .border(
                    width = 1.dp,
                    color =
                      if (selected) tokens.accentPrimary else Color.White.copy(alpha = 0.12f),
                    shape = RoundedCornerShape(10.dp),
                  )
                  .clickable { onSelectCategory(category) }
                  .padding(horizontal = 10.dp, vertical = 7.dp)
            ) {
              Text(
                text = category.label,
                style = MaterialTheme.typography.labelLarge,
                color = if (selected) tokens.accentPrimary else TextSecondary,
              )
            }
          }
        }

        Spacer(Modifier.height(8.dp))

        // Item pills
        Row(
          modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          itemsInCategory.forEach { item ->
            val selected = item == selectedItem
            Row(
              modifier =
                Modifier.clip(RoundedCornerShape(10.dp))
                  .background(
                    if (selected) tokens.accentSecondary.copy(alpha = 0.26f)
                    else NavySurface.copy(alpha = 0.72f)
                  )
                  .border(
                    width = 1.dp,
                    color =
                      if (selected) tokens.accentSecondary else Color.White.copy(alpha = 0.10f),
                    shape = RoundedCornerShape(10.dp),
                  )
                  .clickable { onSelectItem(item) }
                  .padding(horizontal = 10.dp, vertical = 7.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Icon(
                imageVector = item.icon(),
                contentDescription = null,
                tint = if (selected) tokens.accentPrimary else TextSecondary,
                modifier = Modifier.size(15.dp),
              )
              Spacer(Modifier.width(5.dp))
              Text(
                text = item.displayName,
                style = MaterialTheme.typography.bodySmall,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                color = if (selected) TextPrimary else TextSecondary,
              )
            }
          }
        }

        Spacer(Modifier.height(8.dp))

        // Conflict Banner
        AnimatedVisibility(visible = settings.autoCheckConflicts && conflicts.isNotEmpty()) {
          Row(
            modifier =
              Modifier.fillMaxWidth()
                .padding(bottom = 8.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(NeonAmber.copy(alpha = 0.14f))
                .border(1.dp, NeonAmber.copy(alpha = 0.45f), RoundedCornerShape(10.dp))
                .padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Icon(
              imageVector = Icons.Rounded.WarningAmber,
              contentDescription = null,
              tint = NeonAmber,
              modifier = Modifier.size(16.dp),
            )
            Spacer(Modifier.width(6.dp))
            Text(
              text = "${conflicts.size} survival conflict(s) detected",
              style = MaterialTheme.typography.bodySmall,
              color = NeonAmber,
            )
          }
        }

        // Enchantment list
        LazyColumn(
          modifier = Modifier.weight(1f, fill = false).heightIn(max = 260.dp),
          verticalArrangement = Arrangement.spacedBy(6.dp),
          contentPadding = PaddingValues(vertical = 2.dp),
        ) {
          items(enchantments, key = { it.id }) { def ->
            val activeLevel = validSelected[def.id]
            OverlayEnchantRow(
              def = def,
              activeLevel = activeLevel,
              onToggle = { onToggleEnchant(def.id) },
              onDecrement = {
                if (activeLevel != null && activeLevel > 1) {
                  onSetLevel(def.id, activeLevel - 1)
                }
              },
              onIncrement = {
                if (activeLevel != null && activeLevel < def.maxLevel) {
                  onSetLevel(def.id, activeLevel + 1)
                }
              },
            )
          }
        }

        Spacer(Modifier.height(10.dp))

        // Summary + Actions
        GlassCard(
          highlighted = validSelected.isNotEmpty(),
          cornerRadius = 14.dp,
          contentPadding = PaddingValues(10.dp),
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Text(
              text = "${selectedItem.displayName} • ${validSelected.size} Enchant(s)",
              style = MaterialTheme.typography.labelLarge,
              color = TextPrimary,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
            Text(
              text = if (conflicts.isEmpty()) "LOCAL OK" else "CONFLICT",
              style = MaterialTheme.typography.labelSmall,
              color = if (conflicts.isEmpty()) NeonEmerald else NeonAmber,
            )
          }
          Spacer(Modifier.height(8.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            NeonOutlinedButton(
              text = stringResource(R.string.btn_reset_build),
              onClick = onReset,
              testTag = "overlay_reset_button",
              icon = Icons.Rounded.RestartAlt,
              enabled = validSelected.isNotEmpty(),
              modifier = Modifier.weight(1f),
            )
            NeonGradientButton(
              text = stringResource(R.string.btn_copy_build),
              onClick = {
                val summary = EnchantmentCatalog.formatBuildSummary(selectedItem, validSelected)
                val clipboard =
                  context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("XylenMC Build", summary))
                Toast.makeText(
                    context,
                    context.getString(R.string.msg_build_copied),
                    Toast.LENGTH_SHORT,
                  )
                  .show()
              },
              testTag = "overlay_copy_button",
              icon = Icons.Rounded.ContentCopy,
              modifier = Modifier.weight(1.2f),
            )
          }
        }
      }
    }
  }
}

@Composable
private fun OverlayEnchantRow(
  def: EnchantmentDef,
  activeLevel: Int?,
  onToggle: () -> Unit,
  onDecrement: () -> Unit,
  onIncrement: () -> Unit,
) {
  val tokens = LocalXylenTokens.current
  val isSelected = activeLevel != null
  Row(
    modifier =
      Modifier.fillMaxWidth()
        .clip(RoundedCornerShape(12.dp))
        .background(
          if (isSelected) tokens.accentPrimary.copy(alpha = 0.14f)
          else NavySurface.copy(alpha = 0.72f)
        )
        .border(
          width = 1.dp,
          color =
            if (isSelected) tokens.accentPrimary.copy(alpha = 0.65f)
            else Color.White.copy(alpha = 0.08f),
          shape = RoundedCornerShape(12.dp),
        )
        .clickable(onClick = onToggle)
        .padding(horizontal = 10.dp, vertical = 8.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween,
  ) {
    Column(modifier = Modifier.weight(1f)) {
      Text(
        text =
          if (activeLevel != null) "${def.name} ${EnchantmentCatalog.toRoman(activeLevel)}"
          else def.name,
        style = MaterialTheme.typography.bodyMedium,
        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
        color = if (isSelected) TextPrimary else TextSecondary,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
      )
      Text(
        text = "Max ${EnchantmentCatalog.toRoman(def.maxLevel)} • ${def.type.label}",
        style = MaterialTheme.typography.labelSmall,
        color = TextSecondary.copy(alpha = 0.75f),
      )
    }
    if (isSelected && def.maxLevel > 1) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onDecrement, modifier = Modifier.size(34.dp)) {
          Icon(
            imageVector = Icons.Rounded.Remove,
            contentDescription = "Decrease ${def.name} level",
            tint = tokens.accentPrimary,
            modifier = Modifier.size(16.dp),
          )
        }
        IconButton(onClick = onIncrement, modifier = Modifier.size(34.dp)) {
          Icon(
            imageVector = Icons.Rounded.Add,
            contentDescription = "Increase ${def.name} level",
            tint = tokens.accentPrimary,
            modifier = Modifier.size(16.dp),
          )
        }
      }
    }
  }
}
