package com.example

import android.graphics.Color as AndroidColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AutoFixHigh
import androidx.compose.material.icons.outlined.Dns
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.rounded.AutoFixHigh
import androidx.compose.material.icons.rounded.Dns
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.overlay.OverlayController
import com.example.ui.XylenViewModel
import com.example.ui.components.CyberBackground
import com.example.ui.components.XylenLogoMark
import com.example.ui.screens.BuilderScreen
import com.example.ui.screens.ServerAssistantScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.LocalXylenTokens
import com.example.ui.theme.NavyDeep
import com.example.ui.theme.NavySurface
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.XylenMCTheme
import kotlinx.coroutines.launch

const val ROUTE_BUILDER = "builder"
const val ROUTE_SERVER_ASSISTANT = "server_assistant"
const val ROUTE_SETTINGS = "settings"

private data class NavDestination(
  val route: String,
  val labelRes: Int,
  val selectedIcon: ImageVector,
  val unselectedIcon: ImageVector,
  val testTag: String,
)

private val xylenDestinations =
  listOf(
    NavDestination(
      route = ROUTE_BUILDER,
      labelRes = R.string.nav_builder,
      selectedIcon = Icons.Rounded.AutoFixHigh,
      unselectedIcon = Icons.Outlined.AutoFixHigh,
      testTag = "nav_builder",
    ),
    NavDestination(
      route = ROUTE_SERVER_ASSISTANT,
      labelRes = R.string.nav_server,
      selectedIcon = Icons.Rounded.Dns,
      unselectedIcon = Icons.Outlined.Dns,
      testTag = "nav_server",
    ),
    NavDestination(
      route = ROUTE_SETTINGS,
      labelRes = R.string.nav_settings,
      selectedIcon = Icons.Rounded.Settings,
      unselectedIcon = Icons.Outlined.Settings,
      testTag = "nav_settings",
    ),
  )

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge(
      statusBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT),
      navigationBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT),
    )
    setContent { XylenMCApp() }
  }
}

@Composable
fun XylenMCApp(viewModel: XylenViewModel = viewModel()) {
  val uiState by viewModel.uiState.collectAsStateWithLifecycle()
  val context = LocalContext.current
  val lifecycleOwner = LocalLifecycleOwner.current
  var hasOverlayPermission by remember {
    mutableStateOf(OverlayController.canDrawOverlays(context))
  }

  DisposableEffect(lifecycleOwner) {
    val observer = LifecycleEventObserver { _, event ->
      if (event == Lifecycle.Event.ON_RESUME) {
        hasOverlayPermission = OverlayController.canDrawOverlays(context)
      }
    }
    lifecycleOwner.lifecycle.addObserver(observer)
    onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
  }

  XylenMCTheme(settings = uiState.settings) {
    val tokens = LocalXylenTokens.current
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route ?: ROUTE_BUILDER
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    val showMessage: (String) -> Unit = { msg ->
      scope.launch {
        snackbarHostState.currentSnackbarData?.dismiss()
        snackbarHostState.showSnackbar(msg)
      }
    }

    val handleOverlayToggle: () -> Unit = {
      if (!OverlayController.canDrawOverlays(context)) {
        showMessage(context.getString(R.string.msg_overlay_permission_needed))
        OverlayController.openOverlayPermissionSettings(context)
      } else {
        OverlayController.toggleOverlayService(context, uiState.isOverlayRunning)
      }
    }

    val navigateTo: (String) -> Unit = { route ->
      navController.navigate(route) {
        popUpTo(navController.graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
      }
    }

    CyberBackground {
      BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useNavigationRail = maxWidth >= 600.dp

        Scaffold(
          containerColor = Color.Transparent,
          contentWindowInsets = WindowInsets.safeDrawing,
          snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
          bottomBar = {
            if (!useNavigationRail) {
              NavigationBar(
                containerColor = NavyDeep.copy(alpha = 0.94f),
                tonalElevation = 0.dp,
                modifier =
                  Modifier.border(
                    width = 1.dp,
                    color = tokens.accentPrimary.copy(alpha = 0.18f),
                  ),
              ) {
                xylenDestinations.forEach { dest ->
                  val selected = currentRoute == dest.route
                  NavigationBarItem(
                    selected = selected,
                    onClick = { navigateTo(dest.route) },
                    icon = {
                      Icon(
                        imageVector =
                          if (selected) dest.selectedIcon else dest.unselectedIcon,
                        contentDescription = stringResource(dest.labelRes),
                      )
                    },
                    label = {
                      Text(
                        text = stringResource(dest.labelRes),
                        style = MaterialTheme.typography.labelLarge,
                      )
                    },
                    colors =
                      NavigationBarItemDefaults.colors(
                        selectedIconColor = tokens.accentPrimary,
                        selectedTextColor = tokens.accentPrimary,
                        indicatorColor = tokens.accentPrimary.copy(alpha = 0.16f),
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary,
                      ),
                    modifier = Modifier.testTag(dest.testTag),
                  )
                }
              }
            }
          },
        ) { innerPadding ->
          Row(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
            if (useNavigationRail) {
              NavigationRail(
                containerColor = NavyDeep.copy(alpha = 0.94f),
                header = {
                  Box(modifier = Modifier.padding(vertical = 12.dp)) {
                    XylenLogoMark(size = 40.dp, animatedGlow = true)
                  }
                },
                modifier =
                  Modifier.fillMaxHeight()
                    .background(NavySurface.copy(alpha = 0.35f))
                    .border(
                      width = 1.dp,
                      color = tokens.accentPrimary.copy(alpha = 0.16f),
                    ),
              ) {
                xylenDestinations.forEach { dest ->
                  val selected = currentRoute == dest.route
                  NavigationRailItem(
                    selected = selected,
                    onClick = { navigateTo(dest.route) },
                    icon = {
                      Icon(
                        imageVector =
                          if (selected) dest.selectedIcon else dest.unselectedIcon,
                        contentDescription = stringResource(dest.labelRes),
                      )
                    },
                    label = {
                      Text(
                        text = stringResource(dest.labelRes),
                        style = MaterialTheme.typography.labelLarge,
                      )
                    },
                    colors =
                      NavigationRailItemDefaults.colors(
                        selectedIconColor = tokens.accentPrimary,
                        selectedTextColor = TextPrimary,
                        indicatorColor = tokens.accentPrimary.copy(alpha = 0.18f),
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary,
                      ),
                    modifier = Modifier.testTag(dest.testTag),
                  )
                }
              }
              Spacer(Modifier.width(1.dp))
            }

            NavHost(
              navController = navController,
              startDestination = ROUTE_BUILDER,
              modifier = Modifier.weight(1f).fillMaxSize(),
            ) {
              composable(ROUTE_BUILDER) {
                BuilderScreen(
                  uiState = uiState,
                  hasOverlayPermission = hasOverlayPermission,
                  onToggleOverlay = handleOverlayToggle,
                  onSelectCategory = viewModel::selectCategory,
                  onSelectItem = viewModel::selectItem,
                  onToggleEnchantment = viewModel::toggleEnchantment,
                  onSetLevel = viewModel::setEnchantmentLevel,
                  onResetBuild = viewModel::resetCurrentBuild,
                  onShowMessage = showMessage,
                )
              }
              composable(ROUTE_SERVER_ASSISTANT) {
                ServerAssistantScreen(
                  uiState = uiState,
                  onSelectProfile = viewModel::selectServerProfile,
                )
              }
              composable(ROUTE_SETTINGS) {
                SettingsScreen(
                  uiState = uiState,
                  hasOverlayPermission = hasOverlayPermission,
                  onToggleOverlay = handleOverlayToggle,
                  onUpdateButtonSize = viewModel::updateButtonSize,
                  onApplyAnchorPreset = viewModel::applyAnchorPreset,
                  onResetPosition = viewModel::resetOverlayPosition,
                  onUpdateThemePreset = viewModel::updateThemePreset,
                  onUpdateGlassOpacity = viewModel::updateGlassOpacity,
                  onUpdateGlowIntensity = viewModel::updateGlowIntensity,
                  onUpdateAutoCheckConflicts = viewModel::updateAutoCheckConflicts,
                )
              }
            }
          }
        }
      }
    }
  }
}
