package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.XylenRepository
import com.example.model.EnchantmentCatalog
import com.example.model.EnchantmentConflict
import com.example.model.EnchantmentDef
import com.example.model.GearItem
import com.example.model.ItemCategory
import com.example.model.OverlayAnchorPreset
import com.example.model.ServerProfile
import com.example.model.XylenSettings
import com.example.model.XylenThemePreset
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

data class XylenUiState(
  val selectedCategory: ItemCategory = ItemCategory.WEAPONS,
  val selectedItem: GearItem = GearItem.SWORD,
  val itemsInCategory: List<GearItem> = EnchantmentCatalog.itemsForCategory(ItemCategory.WEAPONS),
  val availableEnchantments: List<EnchantmentDef> = EnchantmentCatalog.enchantmentsForItem(GearItem.SWORD),
  val selectedEnchants: Map<String, Int> = emptyMap(),
  val conflicts: List<EnchantmentConflict> = emptyList(),
  val settings: XylenSettings = XylenSettings(),
  val isOverlayRunning: Boolean = false,
  val isOverlayPanelExpanded: Boolean = false,
  val selectedServerProfile: ServerProfile = ServerProfile.VANILLA_REALMS,
)

class XylenViewModel(application: Application) : AndroidViewModel(application) {
  private val repo = XylenRepository.getInstance(application)

  val uiState: StateFlow<XylenUiState> =
    combine(
        repo.selectedCategory,
        repo.selectedItem,
        repo.selectedEnchants,
        repo.settings,
        repo.isOverlayRunning,
        repo.isOverlayPanelExpanded,
        repo.selectedServerProfile,
      ) { values ->
        val category = values[0] as ItemCategory
        val item = values[1] as GearItem
        @Suppress("UNCHECKED_CAST")
        val enchants = values[2] as Map<String, Int>
        val settings = values[3] as XylenSettings
        val overlayRunning = values[4] as Boolean
        val overlayExpanded = values[5] as Boolean
        val serverProfile = values[6] as ServerProfile

        val available = EnchantmentCatalog.enchantmentsForItem(item)
        val validIds = available.map { it.id }.toSet()
        val filteredSelected = enchants.filterKeys { it in validIds }
        val conflicts = EnchantmentCatalog.findConflicts(filteredSelected.keys)

        XylenUiState(
          selectedCategory = category,
          selectedItem = item,
          itemsInCategory = EnchantmentCatalog.itemsForCategory(category),
          availableEnchantments = available,
          selectedEnchants = filteredSelected,
          conflicts = conflicts,
          settings = settings,
          isOverlayRunning = overlayRunning,
          isOverlayPanelExpanded = overlayExpanded,
          selectedServerProfile = serverProfile,
        )
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = XylenUiState(),
      )

  fun selectCategory(category: ItemCategory) = repo.selectCategory(category)

  fun selectItem(item: GearItem) = repo.selectItem(item)

  fun toggleEnchantment(enchantId: String) = repo.toggleEnchantment(enchantId)

  fun setEnchantmentLevel(enchantId: String, level: Int) =
    repo.setEnchantmentLevel(enchantId, level)

  fun resetCurrentBuild() = repo.resetCurrentBuild()

  fun updateButtonSize(sizeDp: Int) = repo.updateButtonSize(sizeDp)

  fun applyAnchorPreset(preset: OverlayAnchorPreset, widthPx: Int, heightPx: Int) =
    repo.applyAnchorPreset(preset, widthPx, heightPx)

  fun resetOverlayPosition(widthPx: Int, heightPx: Int) =
    repo.applyAnchorPreset(OverlayAnchorPreset.MID_LEFT, widthPx, heightPx)

  fun updateThemePreset(preset: XylenThemePreset) = repo.updateThemePreset(preset)

  fun updateGlassOpacity(opacity: Float) = repo.updateGlassOpacity(opacity)

  fun updateGlowIntensity(intensity: Float) = repo.updateGlowIntensity(intensity)

  fun updateAutoCheckConflicts(enabled: Boolean) = repo.updateAutoCheckConflicts(enabled)

  fun selectServerProfile(profile: ServerProfile) = repo.selectServerProfile(profile)
}
