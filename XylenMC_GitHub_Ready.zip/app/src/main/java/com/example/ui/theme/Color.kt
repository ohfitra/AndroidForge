package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Core Dark Navy Surfaces
val NavyVoid = Color(0xFF050914)
val NavyDeep = Color(0xFF090F22)
val NavySurface = Color(0xFF0F172F)
val NavySurfaceElevated = Color(0xFF152142)
val NavyGlassStroke = Color(0x38FFFFFF)

// Signature Neon Accents
val NeonCyan = Color(0xFF00F0FF)
val NeonPurple = Color(0xFF9D4EDD)
val NeonElectricBlue = Color(0xFF38BDF8)
val NeonMagenta = Color(0xFFE879F9)

// Semantic Status Colors
val NeonEmerald = Color(0xFF22E58A)
val NeonAmber = Color(0xFFFBBF24)
val NeonRose = Color(0xFFFF4D6D)

// Typography Neutrals
val TextPrimary = Color(0xFFF1F5FB)
val TextSecondary = Color(0xFF9FB2D3)
val TextMuted = Color(0xFF6B7FA3)
