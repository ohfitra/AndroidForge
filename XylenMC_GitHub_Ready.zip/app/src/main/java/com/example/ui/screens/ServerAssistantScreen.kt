package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Block
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Dns
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.EnchantmentCatalog
import com.example.model.EnchantmentType
import com.example.model.GearItem
import com.example.model.ServerProfile
import com.example.ui.XylenUiState
import com.example.ui.components.GlassCard
import com.example.ui.components.SectionHeader
import com.example.ui.theme.LocalXylenTokens
import com.example.ui.theme.NavyDeep
import com.example.ui.theme.NavySurface
import com.example.ui.theme.NavyVoid
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.NeonRose
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

private enum class CompatibilityStatus(val label: String, val color: Color) {
  ACCEPTED("ACCEPTED", NeonEmerald),
  CONDITIONAL("SERVER CHECK", NeonAmber),
  RESTRICTED("RESTRICTED", NeonRose),
}

@Composable
fun ServerAssistantScreen(
  uiState: XylenUiState,
  onSelectProfile: (ServerProfile) -> Unit,
  modifier: Modifier = Modifier,
) {
  val tokens = LocalXylenTokens.current
  val profile = uiState.selectedServerProfile
  val activeEnchants =
    uiState.availableEnchantments.mapNotNull { def ->
      uiState.selectedEnchants[def.id]?.let { lvl -> def to lvl }
    }

  Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
    LazyColumn(
      modifier = Modifier.fillMaxSize().widthIn(max = 720.dp),
      contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      // Hero Banner
      item(key = "banner") {
        Box(
          modifier =
            Modifier.fillMaxWidth()
              .height(152.dp)
              .clip(RoundedCornerShape(20.dp))
              .border(
                width = 1.dp,
                brush = Brush.linearGradient(listOf(tokens.accentPrimary, tokens.accentSecondary)),
                shape = RoundedCornerShape(20.dp),
              )
        ) {
          Image(
            painter = painterResource(id = R.drawable.img_xylen_banner_1795048886384),
            contentDescription = stringResource(R.string.cd_server_banner),
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize(),
          )
          Box(
            modifier =
              Modifier.fillMaxSize()
                .background(
                  Brush.verticalGradient(
                    listOf(
                      NavyVoid.copy(alpha = 0.45f),
                      NavyDeep.copy(alpha = 0.88f),
                      NavyVoid.copy(alpha = 0.96f),
                    )
                  )
                )
                .padding(16.dp),
            contentAlignment = Alignment.BottomStart,
          ) {
            Column {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  imageVector = Icons.Rounded.Dns,
                  contentDescription = null,
                  tint = tokens.accentPrimary,
                  modifier = Modifier.size(18.dp),
                )
                Spacer(Modifier.width(8.dp))
                Text(
                  text = "LOCAL SERVER ASSISTANT",
                  style = MaterialTheme.typography.titleLarge,
                  color = TextPrimary,
                )
              }
              Spacer(Modifier.height(4.dp))
              Text(
                text =
                  "Inspect how your local XylenMC plan aligns with authoritative Bedrock server rules.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
              )
            }
          }
        }
      }

      // Local Planning vs Server Enforcement Distinction
      item(key = "distinction") {
        GlassCard(highlighted = true, cornerRadius = 18.dp) {
          Text(
            text = "LOCAL PLANNING VS SERVER ENFORCEMENT",
            style = MaterialTheme.typography.titleSmall,
            color = tokens.accentPrimary,
            fontWeight = FontWeight.Bold,
          )
          Spacer(Modifier.height(10.dp))
          BoundaryRow(
            icon = Icons.Rounded.VerifiedUser,
            iconTint = tokens.accentPrimary,
            title = "Local Client Plan (This App)",
            body =
              "XylenMC plans items, enchantment combinations, and reference commands purely on your device.",
          )
          Spacer(Modifier.height(10.dp))
          BoundaryRow(
            icon = Icons.Rounded.Lock,
            iconTint = tokens.accentSecondary,
            title = "Server-Accepted Enchantments",
            body =
              "Multiplayer servers validate every inventory item on the server. Only legitimate in-game enchanting or authorized operator commands apply.",
          )
        }
      }

      // Server Profile Selector
      item(key = "profiles_header") {
        SectionHeader(
          title = "Target Server Environment",
          subtitle = "Test your current build locally against Bedrock rulesets",
        )
      }

      items(ServerProfile.entries, key = { it.id }) { item ->
        val selected = item == profile
        GlassCard(
          highlighted = selected,
          cornerRadius = 16.dp,
          contentPadding = PaddingValues(14.dp),
          modifier =
            Modifier.fillMaxWidth()
              .minimumInteractiveComponentSize()
              .clickable { onSelectProfile(item) }
              .testTag("server_profile_${item.id}"),
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Text(
              text = item.title,
              style = MaterialTheme.typography.titleMedium,
              color = TextPrimary,
              fontWeight = FontWeight.Bold,
              modifier = Modifier.weight(1f),
            )
            Box(
              modifier =
                Modifier.clip(RoundedCornerShape(8.dp))
                  .background(
                    if (selected) tokens.accentPrimary.copy(alpha = 0.22f)
                    else NavyDeep.copy(alpha = 0.85f)
                  )
                  .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
              Text(
                text = item.badge,
                style = MaterialTheme.typography.labelSmall,
                color = if (selected) tokens.accentPrimary else TextSecondary,
              )
            }
          }
          Spacer(Modifier.height(4.dp))
          Text(
            text = item.subtitle,
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary,
          )
          if (selected) {
            Spacer(Modifier.height(8.dp))
            Text(
              text = item.enforcementNote,
              style = MaterialTheme.typography.bodySmall,
              color = tokens.accentPrimary,
            )
          }
        }
      }

      // Live Build Analyzer
      item(key = "analysis_header") {
        SectionHeader(
          title = "Current Build Check: ${uiState.selectedItem.displayName}",
          subtitle = "Local simulation for ${profile.title}",
        )
      }

      item(key = "analysis_card") {
        GlassCard(cornerRadius = 18.dp) {
          if (uiState.selectedItem == GearItem.SPEAR && !profile.allowsExperimentalSpear) {
            StatusBanner(
              status = CompatibilityStatus.CONDITIONAL,
              message =
                "Spear is not part of standard ${profile.title} survival gear unless enabled by a server behavior pack.",
            )
            Spacer(Modifier.height(10.dp))
          }

          if (uiState.conflicts.isNotEmpty() && !profile.allowsConflicts) {
            StatusBanner(
              status = CompatibilityStatus.RESTRICTED,
              message =
                "${uiState.conflicts.size} incompatible enchantment pair(s) will be rejected in ${profile.title}.",
            )
            Spacer(Modifier.height(10.dp))
          }

          if (activeEnchants.isEmpty()) {
            Text(
              text =
                "No enchantments selected on ${uiState.selectedItem.displayName}. Choose enchantments in the Builder tab to run a local server compatibility check.",
              style = MaterialTheme.typography.bodyMedium,
              color = TextSecondary,
            )
          } else {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
              activeEnchants.forEach { (def, lvl) ->
                val hasConflict =
                  uiState.conflicts.any { it.firstId == def.id || it.secondId == def.id }
                val status =
                  when {
                    profile == ServerProfile.FEATURED_SERVERS -> CompatibilityStatus.CONDITIONAL
                    hasConflict && !profile.allowsConflicts -> CompatibilityStatus.RESTRICTED
                    def.type == EnchantmentType.CURSE && !profile.allowsCurses ->
                      CompatibilityStatus.RESTRICTED
                    def.treasureOnly && !profile.allowsTreasure ->
                      CompatibilityStatus.CONDITIONAL
                    else -> CompatibilityStatus.ACCEPTED
                  }
                val note =
                  when (status) {
                    CompatibilityStatus.ACCEPTED ->
                      "Valid in ${profile.title} up to ${EnchantmentCatalog.toRoman(def.maxLevel)}."
                    CompatibilityStatus.CONDITIONAL ->
                      if (profile == ServerProfile.FEATURED_SERVERS) {
                        "Featured servers override player gear with mini-game kits."
                      } else {
                        "Treasure/rare enchantment — obtain via loot or trading."
                      }
                    CompatibilityStatus.RESTRICTED ->
                      "Conflicts with another selected enchantment or disallowed by server ruleset."
                  }

                Row(
                  modifier =
                    Modifier.fillMaxWidth()
                      .clip(RoundedCornerShape(12.dp))
                      .background(NavyDeep.copy(alpha = 0.78f))
                      .border(1.dp, status.color.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
                      .padding(12.dp),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                  Column(modifier = Modifier.weight(1f)) {
                    Text(
                      text = "${def.name} ${EnchantmentCatalog.toRoman(lvl)}",
                      style = MaterialTheme.typography.titleSmall,
                      color = TextPrimary,
                      fontWeight = FontWeight.Bold,
                    )
                    Spacer(Modifier.height(2.dp))
                    Text(
                      text = note,
                      style = MaterialTheme.typography.bodySmall,
                      color = TextSecondary,
                    )
                  }
                  Spacer(Modifier.width(8.dp))
                  Row(
                    modifier =
                      Modifier.clip(RoundedCornerShape(8.dp))
                        .background(status.color.copy(alpha = 0.16f))
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                  ) {
                    Icon(
                      imageVector =
                        when (status) {
                          CompatibilityStatus.ACCEPTED -> Icons.Rounded.CheckCircle
                          CompatibilityStatus.CONDITIONAL -> Icons.Rounded.WarningAmber
                          CompatibilityStatus.RESTRICTED -> Icons.Rounded.Block
                        },
                      contentDescription = null,
                      tint = status.color,
                      modifier = Modifier.size(14.dp),
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(
                      text = status.label,
                      style = MaterialTheme.typography.labelSmall,
                      color = status.color,
                    )
                  }
                }
              }
            }
          }
        }
      }

      // Fair Play Guarantee
      item(key = "fair_play") {
        GlassCard(cornerRadius = 18.dp) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Rounded.Shield,
              contentDescription = null,
              tint = NeonEmerald,
              modifier = Modifier.size(22.dp),
            )
            Spacer(Modifier.width(10.dp))
            Text(
              text = "FAIR-PLAY & AUTHORIZATION POLICY",
              style = MaterialTheme.typography.titleSmall,
              color = NeonEmerald,
              fontWeight = FontWeight.Bold,
            )
          }
          Spacer(Modifier.height(8.dp))
          Text(
            text =
              "XylenMC Client Edition operates strictly as a local planning & overlay companion. It does not inject packets, bypass anti-cheat systems, exploit server vulnerabilities, or modify server inventories without server authorization.",
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary,
          )
        }
      }

      item(key = "bottom_spacer") { Spacer(Modifier.height(12.dp)) }
    }
  }
}

@Composable
private fun BoundaryRow(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  iconTint: Color,
  title: String,
  body: String,
) {
  Row(verticalAlignment = Alignment.Top) {
    Box(
      modifier =
        Modifier.size(34.dp)
          .clip(RoundedCornerShape(10.dp))
          .background(iconTint.copy(alpha = 0.16f)),
      contentAlignment = Alignment.Center,
    ) {
      Icon(
        imageVector = icon,
        contentDescription = null,
        tint = iconTint,
        modifier = Modifier.size(18.dp),
      )
    }
    Spacer(Modifier.width(10.dp))
    Column(modifier = Modifier.weight(1f)) {
      Text(
        text = title,
        style = MaterialTheme.typography.labelLarge,
        color = TextPrimary,
        fontWeight = FontWeight.Bold,
      )
      Spacer(Modifier.height(2.dp))
      Text(
        text = body,
        style = MaterialTheme.typography.bodySmall,
        color = TextSecondary,
      )
    }
  }
}

@Composable
private fun StatusBanner(status: CompatibilityStatus, message: String) {
  Row(
    modifier =
      Modifier.fillMaxWidth()
        .clip(RoundedCornerShape(12.dp))
        .background(status.color.copy(alpha = 0.14f))
        .border(1.dp, status.color.copy(alpha = 0.45f), RoundedCornerShape(12.dp))
        .padding(10.dp),
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Icon(
      imageVector =
        if (status == CompatibilityStatus.RESTRICTED) Icons.Rounded.Block
        else Icons.Rounded.WarningAmber,
      contentDescription = null,
      tint = status.color,
      modifier = Modifier.size(18.dp),
    )
    Spacer(Modifier.width(8.dp))
    Text(
      text = message,
      style = MaterialTheme.typography.bodySmall,
      color = status.color,
    )
  }
}
