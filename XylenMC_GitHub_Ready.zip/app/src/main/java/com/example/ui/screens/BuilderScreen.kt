package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material.icons.rounded.RestartAlt
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.EnchantmentCatalog
import com.example.model.EnchantmentDef
import com.example.model.EnchantmentType
import com.example.model.GearItem
import com.example.model.ItemCategory
import com.example.ui.XylenUiState
import com.example.ui.components.GlassCard
import com.example.ui.components.NeonGradientButton
import com.example.ui.components.NeonOutlinedButton
import com.example.ui.components.OverlayStatusPill
import com.example.ui.components.SectionHeader
import com.example.ui.components.XylenLogoMark
import com.example.ui.components.badgeLabel
import com.example.ui.components.icon
import com.example.ui.theme.LocalXylenTokens
import com.example.ui.theme.NavyDeep
import com.example.ui.theme.NavySurface
import com.example.ui.theme.NavySurfaceElevated
import com.example.ui.theme.NavyVoid
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.NeonRose
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun BuilderScreen(
  uiState: XylenUiState,
  hasOverlayPermission: Boolean,
  onToggleOverlay: () -> Unit,
  onSelectCategory: (ItemCategory) -> Unit,
  onSelectItem: (GearItem) -> Unit,
  onToggleEnchantment: (String) -> Unit,
  onSetLevel: (String, Int) -> Unit,
  onResetBuild: () -> Unit,
  onShowMessage: (String) -> Unit,
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current
  val tokens = LocalXylenTokens.current
  var showCommands by remember { mutableStateOf(false) }

  Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
    LazyColumn(
      modifier = Modifier.fillMaxSize().widthIn(max = 720.dp),
      contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      // Hero Header
      item(key = "header") {
        GlassCard(
          highlighted = true,
          cornerRadius = 20.dp,
          contentPadding = PaddingValues(16.dp),
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
              XylenLogoMark(size = 46.dp, animatedGlow = true)
              Spacer(Modifier.width(12.dp))
              Column {
                Text(
                  text = "XYLENMC",
                  style = MaterialTheme.typography.headlineSmall,
                  color = TextPrimary,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                )
                Text(
                  text = stringResource(R.string.app_edition),
                  style = MaterialTheme.typography.labelMedium,
                  color = tokens.accentPrimary,
                )
              }
            }
            OverlayStatusPill(
              isRunning = uiState.isOverlayRunning,
              hasPermission = hasOverlayPermission,
              onClick = onToggleOverlay,
              testTag = "builder_overlay_toggle_pill",
            )
          }
        }
      }

      // Categories
      item(key = "categories") {
        SectionHeader(
          title = "Gear Category",
          subtitle = "Select Armor, Weapons, Tools or Utility",
        )
        Spacer(Modifier.height(10.dp))
        Row(
          modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          ItemCategory.entries.forEach { category ->
            val selected = category == uiState.selectedCategory
            val count = EnchantmentCatalog.itemsForCategory(category).size
            CategoryChip(
              category = category,
              itemCount = count,
              selected = selected,
              onClick = { onSelectCategory(category) },
            )
          }
        }
      }

      // Items in Category
      item(key = "items") {
        SectionHeader(
          title = "${uiState.selectedCategory.label} Arsenal",
          subtitle = uiState.selectedCategory.tagline,
        )
        Spacer(Modifier.height(10.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
          items(uiState.itemsInCategory, key = { it.id }) { item ->
            GearItemCard(
              item = item,
              selected = item == uiState.selectedItem,
              onClick = { onSelectItem(item) },
            )
          }
        }
      }

      // Active Item Banner
      item(key = "active_item_card") {
        AnimatedContent(
          targetState = uiState.selectedItem,
          transitionSpec = { fadeIn() togetherWith fadeOut() },
          label = "selected_item_transition",
        ) { activeItem ->
          GlassCard(cornerRadius = 16.dp, contentPadding = PaddingValues(14.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Box(
                modifier =
                  Modifier.size(44.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                      Brush.linearGradient(
                        listOf(
                          tokens.accentPrimary.copy(alpha = 0.22f),
                          tokens.accentSecondary.copy(alpha = 0.22f),
                        )
                      )
                    )
                    .border(
                      1.dp,
                      tokens.accentPrimary.copy(alpha = 0.45f),
                      RoundedCornerShape(12.dp),
                    ),
                contentAlignment = Alignment.Center,
              ) {
                Icon(
                  imageVector = activeItem.icon(),
                  contentDescription = activeItem.displayName,
                  tint = tokens.accentPrimary,
                  modifier = Modifier.size(24.dp),
                )
              }
              Spacer(Modifier.width(12.dp))
              Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Text(
                    text = activeItem.displayName,
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                  )
                  Spacer(Modifier.width(8.dp))
                  Text(
                    text = activeItem.bedrockId,
                    style = MaterialTheme.typography.labelSmall,
                    color = tokens.accentPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                  )
                }
                Spacer(Modifier.height(2.dp))
                Text(
                  text = activeItem.summary,
                  style = MaterialTheme.typography.bodySmall,
                  color = TextSecondary,
                )
              }
            }
            if (activeItem.compatibilityNote != null) {
              Spacer(Modifier.height(10.dp))
              Row(
                modifier =
                  Modifier.fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(NeonAmber.copy(alpha = 0.12f))
                    .border(1.dp, NeonAmber.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Icon(
                  imageVector = Icons.Rounded.Info,
                  contentDescription = null,
                  tint = NeonAmber,
                  modifier = Modifier.size(16.dp),
                )
                Spacer(Modifier.width(8.dp))
                Text(
                  text = activeItem.compatibilityNote,
                  style = MaterialTheme.typography.bodySmall,
                  color = NeonAmber,
                )
              }
            }
          }
        }
      }

      // Enchantments Header
      item(key = "enchants_header") {
        SectionHeader(
          title = "Enchantment Matrix",
          subtitle = "${uiState.availableEnchantments.size} compatible enchantments for ${uiState.selectedItem.displayName}",
          trailing = {
            Text(
              text = "${uiState.selectedEnchants.size} ACTIVE",
              style = MaterialTheme.typography.labelMedium,
              color = if (uiState.selectedEnchants.isNotEmpty()) tokens.accentPrimary else TextMuted,
            )
          },
        )
      }

      // Enchantments List
      items(uiState.availableEnchantments, key = { "${uiState.selectedItem.id}_${it.id}" }) { def ->
        val activeLevel = uiState.selectedEnchants[def.id]
        val itemConflicts =
          if (uiState.settings.autoCheckConflicts && activeLevel != null) {
            uiState.conflicts.filter { it.firstId == def.id || it.secondId == def.id }
          } else {
            emptyList()
          }
        EnchantmentCard(
          def = def,
          activeLevel = activeLevel,
          hasConflict = itemConflicts.isNotEmpty(),
          conflictDetail = itemConflicts.firstOrNull()?.message,
          onToggle = { onToggleEnchantment(def.id) },
          onSetLevel = { lvl -> onSetLevel(def.id, lvl) },
        )
      }

      // Build Summary Card
      item(key = "build_summary") {
        BuildSummaryCard(
          uiState = uiState,
          showCommands = showCommands,
          onToggleCommands = { showCommands = !showCommands },
          onCopyBuild = {
            val formatted =
              EnchantmentCatalog.formatBuildSummary(uiState.selectedItem, uiState.selectedEnchants)
            val clipboard =
              context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("XylenMC Build", formatted))
            onShowMessage(context.getString(R.string.msg_build_copied))
          },
          onResetBuild = {
            onResetBuild()
            onShowMessage(context.getString(R.string.msg_build_reset))
          },
        )
      }

      item(key = "bottom_spacer") { Spacer(Modifier.height(12.dp)) }
    }
  }
}

@Composable
private fun CategoryChip(
  category: ItemCategory,
  itemCount: Int,
  selected: Boolean,
  onClick: () -> Unit,
) {
  val tokens = LocalXylenTokens.current
  val shape = RoundedCornerShape(14.dp)
  Row(
    modifier =
      Modifier.minimumInteractiveComponentSize()
        .clip(shape)
        .background(
          if (selected) {
            Brush.linearGradient(
              listOf(
                tokens.accentPrimary.copy(alpha = 0.24f),
                tokens.accentSecondary.copy(alpha = 0.24f),
              )
            )
          } else {
            Brush.linearGradient(listOf(NavySurface.copy(alpha = 0.85f), NavySurface.copy(alpha = 0.85f)))
          }
        )
        .border(
          width = if (selected) 1.5.dp else 1.dp,
          brush =
            if (selected) Brush.linearGradient(listOf(tokens.accentPrimary, tokens.accentSecondary))
            else Brush.linearGradient(listOf(Color.White.copy(alpha = 0.12f), Color.White.copy(alpha = 0.08f))),
          shape = shape,
        )
        .clickable(role = Role.Tab, onClick = onClick)
        .padding(horizontal = 14.dp, vertical = 10.dp)
        .testTag("category_chip_${category.name.lowercase()}"),
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Icon(
      imageVector = category.icon(),
      contentDescription = null,
      tint = if (selected) tokens.accentPrimary else TextSecondary,
      modifier = Modifier.size(18.dp),
    )
    Spacer(Modifier.width(8.dp))
    Text(
      text = category.label,
      style = MaterialTheme.typography.labelLarge,
      color = if (selected) TextPrimary else TextSecondary,
      fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
    )
    Spacer(Modifier.width(6.dp))
    Box(
      modifier =
        Modifier.clip(CircleShape)
          .background(if (selected) tokens.accentPrimary.copy(alpha = 0.22f) else NavyDeep)
          .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
      Text(
        text = itemCount.toString(),
        style = MaterialTheme.typography.labelSmall,
        color = if (selected) tokens.accentPrimary else TextMuted,
      )
    }
  }
}

@Composable
private fun GearItemCard(
  item: GearItem,
  selected: Boolean,
  onClick: () -> Unit,
) {
  val tokens = LocalXylenTokens.current
  val shape = RoundedCornerShape(16.dp)
  Column(
    modifier =
      Modifier.width(106.dp)
        .minimumInteractiveComponentSize()
        .clip(shape)
        .background(
          if (selected) NavySurfaceElevated.copy(alpha = 0.94f)
          else NavySurface.copy(alpha = 0.78f)
        )
        .border(
          width = if (selected) 1.5.dp else 1.dp,
          brush =
            if (selected) Brush.linearGradient(listOf(tokens.accentPrimary, tokens.accentSecondary))
            else Brush.linearGradient(listOf(Color.White.copy(alpha = 0.10f), Color.White.copy(alpha = 0.06f))),
          shape = shape,
        )
        .clickable(role = Role.RadioButton, onClick = onClick)
        .padding(horizontal = 10.dp, vertical = 12.dp)
        .testTag("gear_item_${item.id}"),
    horizontalAlignment = Alignment.CenterHorizontally,
  ) {
    Box(
      modifier =
        Modifier.size(38.dp)
          .clip(RoundedCornerShape(11.dp))
          .background(
            if (selected) tokens.accentPrimary.copy(alpha = 0.20f)
            else NavyDeep.copy(alpha = 0.85f)
          ),
      contentAlignment = Alignment.Center,
    ) {
      Icon(
        imageVector = item.icon(),
        contentDescription = item.displayName,
        tint = if (selected) tokens.accentPrimary else TextSecondary,
        modifier = Modifier.size(21.dp),
      )
    }
    Spacer(Modifier.height(8.dp))
    Text(
      text = item.displayName,
      style = MaterialTheme.typography.bodySmall,
      fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
      color = if (selected) TextPrimary else TextSecondary,
      maxLines = 1,
      overflow = TextOverflow.Ellipsis,
    )
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun EnchantmentCard(
  def: EnchantmentDef,
  activeLevel: Int?,
  hasConflict: Boolean,
  conflictDetail: String?,
  onToggle: () -> Unit,
  onSetLevel: (Int) -> Unit,
) {
  val tokens = LocalXylenTokens.current
  val isSelected = activeLevel != null
  val typeColor =
    when (def.type) {
      EnchantmentType.COMBAT -> tokens.accentPrimary
      EnchantmentType.PROTECTION -> tokens.accentTertiary
      EnchantmentType.UTILITY -> NeonEmerald
      EnchantmentType.DURABILITY -> tokens.accentSecondary
      EnchantmentType.TREASURE -> NeonAmber
      EnchantmentType.CURSE -> NeonRose
    }

  GlassCard(
    highlighted = isSelected,
    cornerRadius = 16.dp,
    contentPadding = PaddingValues(14.dp),
    modifier =
      Modifier.fillMaxWidth()
        .clickable(onClick = onToggle)
        .testTag("enchant_card_${def.id}"),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Column(modifier = Modifier.weight(1f)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text =
              if (activeLevel != null) {
                "${def.name} ${EnchantmentCatalog.toRoman(activeLevel)}"
              } else {
                def.name
              },
            style = MaterialTheme.typography.titleMedium,
            color = if (isSelected) TextPrimary else TextSecondary,
            fontWeight = FontWeight.Bold,
          )
          Spacer(Modifier.width(8.dp))
          Box(
            modifier =
              Modifier.clip(RoundedCornerShape(6.dp))
                .background(typeColor.copy(alpha = 0.16f))
                .padding(horizontal = 6.dp, vertical = 2.dp)
          ) {
            Text(
              text = def.type.badgeLabel(),
              style = MaterialTheme.typography.labelSmall,
              color = typeColor,
            )
          }
        }
        Spacer(Modifier.height(3.dp))
        Text(
          text = def.description,
          style = MaterialTheme.typography.bodySmall,
          color = TextSecondary,
        )
      }
      Spacer(Modifier.width(10.dp))
      Switch(
        checked = isSelected,
        onCheckedChange = { onToggle() },
        colors =
          SwitchDefaults.colors(
            checkedThumbColor = NavyVoid,
            checkedTrackColor = tokens.accentPrimary,
            uncheckedThumbColor = TextSecondary,
            uncheckedTrackColor = NavyDeep,
          ),
        modifier = Modifier.testTag("enchant_switch_${def.id}"),
      )
    }

    AnimatedVisibility(visible = isSelected) {
      Column(modifier = Modifier.fillMaxWidth().padding(top = 12.dp)) {
        if (def.maxLevel > 1) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            FlowRow(
              horizontalArrangement = Arrangement.spacedBy(6.dp),
              verticalArrangement = Arrangement.spacedBy(6.dp),
              modifier = Modifier.weight(1f),
            ) {
              for (lvl in 1..def.maxLevel) {
                val selectedLvl = activeLevel == lvl
                Box(
                  modifier =
                    Modifier.minimumInteractiveComponentSize()
                      .clip(RoundedCornerShape(10.dp))
                      .background(
                        if (selectedLvl) tokens.accentPrimary.copy(alpha = 0.25f)
                        else NavyDeep.copy(alpha = 0.85f)
                      )
                      .border(
                        width = 1.dp,
                        color =
                          if (selectedLvl) tokens.accentPrimary
                          else Color.White.copy(alpha = 0.12f),
                        shape = RoundedCornerShape(10.dp),
                      )
                      .clickable { onSetLevel(lvl) }
                      .padding(horizontal = 12.dp, vertical = 8.dp)
                      .testTag("enchant_level_${def.id}_$lvl"),
                  contentAlignment = Alignment.Center,
                ) {
                  Text(
                    text = EnchantmentCatalog.toRoman(lvl),
                    style = MaterialTheme.typography.labelLarge,
                    color = if (selectedLvl) tokens.accentPrimary else TextSecondary,
                    fontWeight = FontWeight.Bold,
                  )
                }
              }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
              IconButton(
                onClick = { if ((activeLevel ?: 1) > 1) onSetLevel((activeLevel ?: 1) - 1) },
                enabled = (activeLevel ?: 1) > 1,
                modifier = Modifier.size(48.dp).testTag("enchant_dec_${def.id}"),
              ) {
                Icon(
                  imageVector = Icons.Rounded.Remove,
                  contentDescription = "Decrease ${def.name} level",
                  tint = if ((activeLevel ?: 1) > 1) tokens.accentPrimary else TextMuted,
                )
              }
              IconButton(
                onClick = {
                  if ((activeLevel ?: 1) < def.maxLevel) onSetLevel((activeLevel ?: 1) + 1)
                },
                enabled = (activeLevel ?: 1) < def.maxLevel,
                modifier = Modifier.size(48.dp).testTag("enchant_inc_${def.id}"),
              ) {
                Icon(
                  imageVector = Icons.Rounded.Add,
                  contentDescription = "Increase ${def.name} level",
                  tint =
                    if ((activeLevel ?: 1) < def.maxLevel) tokens.accentPrimary else TextMuted,
                )
              }
            }
          }
        } else {
          Text(
            text = "Single-tier enchantment (Level I)",
            style = MaterialTheme.typography.labelMedium,
            color = tokens.accentPrimary,
          )
        }

        if (hasConflict && conflictDetail != null) {
          Spacer(Modifier.height(8.dp))
          Row(
            modifier =
              Modifier.fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(NeonAmber.copy(alpha = 0.14f))
                .border(1.dp, NeonAmber.copy(alpha = 0.45f), RoundedCornerShape(10.dp))
                .padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Icon(
              imageVector = Icons.Rounded.WarningAmber,
              contentDescription = null,
              tint = NeonAmber,
              modifier = Modifier.size(16.dp),
            )
            Spacer(Modifier.width(6.dp))
            Text(
              text = conflictDetail,
              style = MaterialTheme.typography.bodySmall,
              color = NeonAmber,
            )
          }
        }
      }
    }
  }
}

@Composable
private fun BuildSummaryCard(
  uiState: XylenUiState,
  showCommands: Boolean,
  onToggleCommands: () -> Unit,
  onCopyBuild: () -> Unit,
  onResetBuild: () -> Unit,
) {
  val tokens = LocalXylenTokens.current
  val activeDefs =
    uiState.availableEnchantments.mapNotNull { def ->
      uiState.selectedEnchants[def.id]?.let { lvl -> def to lvl }
    }
  val hasConflicts = uiState.conflicts.isNotEmpty()

  GlassCard(
    highlighted = activeDefs.isNotEmpty(),
    cornerRadius = 20.dp,
    contentPadding = PaddingValues(16.dp),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = "BUILD SUMMARY",
          style = MaterialTheme.typography.titleSmall,
          color = tokens.accentPrimary,
          fontWeight = FontWeight.Bold,
        )
        Spacer(Modifier.height(2.dp))
        Text(
          text = "${uiState.selectedCategory.label} • ${uiState.selectedItem.displayName}",
          style = MaterialTheme.typography.titleMedium,
          color = TextPrimary,
          fontWeight = FontWeight.Bold,
        )
      }
      Row(
        modifier =
          Modifier.clip(RoundedCornerShape(50))
            .background(
              if (hasConflicts) NeonAmber.copy(alpha = 0.15f)
              else NeonEmerald.copy(alpha = 0.15f)
            )
            .border(
              width = 1.dp,
              color =
                if (hasConflicts) NeonAmber.copy(alpha = 0.5f)
                else NeonEmerald.copy(alpha = 0.5f),
              shape = RoundedCornerShape(50),
            )
            .padding(horizontal = 10.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Icon(
          imageVector =
            if (hasConflicts) Icons.Rounded.WarningAmber else Icons.Rounded.CheckCircle,
          contentDescription = null,
          tint = if (hasConflicts) NeonAmber else NeonEmerald,
          modifier = Modifier.size(14.dp),
        )
        Spacer(Modifier.width(5.dp))
        Text(
          text = if (hasConflicts) "${uiState.conflicts.size} CONFLICT" else "SURVIVAL OK",
          style = MaterialTheme.typography.labelSmall,
          color = if (hasConflicts) NeonAmber else NeonEmerald,
        )
      }
    }

    Spacer(Modifier.height(12.dp))

    if (activeDefs.isEmpty()) {
      Box(
        modifier =
          Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(NavyDeep.copy(alpha = 0.72f))
            .padding(14.dp)
      ) {
        Text(
          text = "No enchantments selected yet. Tap any enchantment above to build your local loadout.",
          style = MaterialTheme.typography.bodySmall,
          color = TextSecondary,
        )
      }
    } else {
      Column(
        modifier =
          Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(NavyDeep.copy(alpha = 0.78f))
            .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(14.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        activeDefs.forEach { (def, lvl) ->
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Text(
              text = "• ${def.name}",
              style = MaterialTheme.typography.bodyMedium,
              color = TextPrimary,
              fontWeight = FontWeight.Medium,
            )
            Text(
              text = EnchantmentCatalog.toRoman(lvl),
              style = MaterialTheme.typography.labelMedium,
              color = tokens.accentPrimary,
              fontWeight = FontWeight.Bold,
            )
          }
        }
      }

      Spacer(Modifier.height(10.dp))

      Row(
        modifier =
          Modifier.fillMaxWidth()
            .minimumInteractiveComponentSize()
            .clip(RoundedCornerShape(10.dp))
            .background(NavyDeep.copy(alpha = 0.6f))
            .clickable(onClick = onToggleCommands)
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .testTag("toggle_commands_preview"),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Rounded.Code,
            contentDescription = null,
            tint = tokens.accentSecondary,
            modifier = Modifier.size(18.dp),
          )
          Spacer(Modifier.width(8.dp))
          Text(
            text = "Local Bedrock Command Reference",
            style = MaterialTheme.typography.labelLarge,
            color = TextSecondary,
          )
        }
        Icon(
          imageVector =
            if (showCommands) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,
          contentDescription = null,
          tint = TextSecondary,
        )
      }

      AnimatedVisibility(visible = showCommands) {
        val commands =
          EnchantmentCatalog.formatCommandLines(uiState.selectedItem, uiState.selectedEnchants)
        Column(
          modifier =
            Modifier.fillMaxWidth()
              .padding(top = 8.dp)
              .clip(RoundedCornerShape(12.dp))
              .background(NavyVoid.copy(alpha = 0.9f))
              .border(1.dp, tokens.accentSecondary.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
              .padding(12.dp),
          verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
          commands.forEach { cmd ->
            Text(
              text = cmd,
              style = MaterialTheme.typography.labelMedium,
              color = tokens.accentPrimary,
            )
          }
          Spacer(Modifier.height(4.dp))
          Text(
            text = "Reference only — requires operator permission or creative mode in-game.",
            style = MaterialTheme.typography.bodySmall,
            color = TextMuted,
          )
        }
      }
    }

    Spacer(Modifier.height(14.dp))

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      NeonOutlinedButton(
        text = stringResource(R.string.btn_reset_build),
        onClick = onResetBuild,
        testTag = "reset_build_button",
        icon = Icons.Rounded.RestartAlt,
        enabled = activeDefs.isNotEmpty(),
        modifier = Modifier.weight(1f),
      )
      NeonGradientButton(
        text = stringResource(R.string.btn_copy_build),
        onClick = onCopyBuild,
        testTag = "copy_build_button",
        icon = Icons.Rounded.ContentCopy,
        modifier = Modifier.weight(1.4f),
      )
    }
  }
}
