package com.example.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoFixHigh
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Brush
import androidx.compose.material.icons.rounded.Build
import androidx.compose.material.icons.rounded.Checkroom
import androidx.compose.material.icons.rounded.Construction
import androidx.compose.material.icons.rounded.ContentCut
import androidx.compose.material.icons.rounded.DirectionsRun
import androidx.compose.material.icons.rounded.Flight
import androidx.compose.material.icons.rounded.Gavel
import androidx.compose.material.icons.rounded.Hardware
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.Phishing
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.SportsMartialArts
import androidx.compose.material.icons.rounded.Straighten
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material.icons.rounded.Waves
import androidx.compose.material.icons.rounded.Whatshot
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.model.EnchantmentType
import com.example.model.GearItem
import com.example.model.ItemCategory

fun ItemCategory.icon(): ImageVector =
  when (this) {
    ItemCategory.ARMOR -> Icons.Rounded.Shield
    ItemCategory.WEAPONS -> Icons.Rounded.SportsMartialArts
    ItemCategory.TOOLS -> Icons.Rounded.Construction
    ItemCategory.UTILITY -> Icons.Rounded.LocalFireDepartment
  }

fun GearItem.icon(): ImageVector =
  when (this) {
    GearItem.HELMET -> Icons.Rounded.VerifiedUser
    GearItem.CHESTPLATE -> Icons.Rounded.Security
    GearItem.LEGGINGS -> Icons.Rounded.Checkroom
    GearItem.BOOTS -> Icons.Rounded.DirectionsRun
    GearItem.ELYTRA -> Icons.Rounded.Flight
    GearItem.SWORD -> Icons.Rounded.SportsMartialArts
    GearItem.SPEAR -> Icons.Rounded.Straighten
    GearItem.MACE -> Icons.Rounded.Gavel
    GearItem.BOW -> Icons.Rounded.Bolt
    GearItem.CROSSBOW -> Icons.Rounded.AutoFixHigh
    GearItem.TRIDENT -> Icons.Rounded.Waves
    GearItem.PICKAXE -> Icons.Rounded.Hardware
    GearItem.AXE -> Icons.Rounded.Construction
    GearItem.SHOVEL -> Icons.Rounded.Build
    GearItem.HOE -> Icons.Rounded.Build
    GearItem.SHEARS -> Icons.Rounded.ContentCut
    GearItem.FISHING_ROD -> Icons.Rounded.Phishing
    GearItem.BRUSH -> Icons.Rounded.Brush
    GearItem.SHIELD -> Icons.Rounded.Shield
    GearItem.FLINT_AND_STEEL -> Icons.Rounded.Whatshot
  }

fun EnchantmentType.badgeLabel(): String = label.uppercase()
