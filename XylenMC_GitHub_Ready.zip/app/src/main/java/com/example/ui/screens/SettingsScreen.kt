package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.OpenInNew
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.RestartAlt
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.model.FloatingButtonSize
import com.example.model.OverlayAnchorPreset
import com.example.model.XylenThemePreset
import com.example.overlay.OverlayController
import com.example.ui.XylenUiState
import com.example.ui.components.GlassCard
import com.example.ui.components.NeonGradientButton
import com.example.ui.components.NeonOutlinedButton
import com.example.ui.components.SectionHeader
import com.example.ui.components.XylenLogoMark
import com.example.ui.theme.LocalXylenTokens
import com.example.ui.theme.NavyDeep
import com.example.ui.theme.NavySurfaceElevated
import com.example.ui.theme.NavyVoid
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlin.math.roundToInt

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
  uiState: XylenUiState,
  hasOverlayPermission: Boolean,
  onToggleOverlay: () -> Unit,
  onUpdateButtonSize: (Int) -> Unit,
  onApplyAnchorPreset: (OverlayAnchorPreset, Int, Int) -> Unit,
  onResetPosition: (Int, Int) -> Unit,
  onUpdateThemePreset: (XylenThemePreset) -> Unit,
  onUpdateGlassOpacity: (Float) -> Unit,
  onUpdateGlowIntensity: (Float) -> Unit,
  onUpdateAutoCheckConflicts: (Boolean) -> Unit,
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current
  val tokens = LocalXylenTokens.current
  val settings = uiState.settings
  val metrics = context.resources.displayMetrics

  var hasNotificationPermission by remember {
    mutableStateOf(
      Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
        ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
          PackageManager.PERMISSION_GRANTED
    )
  }

  val notifLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
      hasNotificationPermission = granted
    }

  Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
    LazyColumn(
      modifier = Modifier.fillMaxSize().widthIn(max = 720.dp),
      contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      item(key = "settings_header") {
        SectionHeader(
          title = "XylenMC Settings",
          subtitle = "Floating HUD customization, theme presets & client branding",
        )
      }

      // Floating Overlay Service & Permissions
      item(key = "overlay_service_card") {
        GlassCard(highlighted = uiState.isOverlayRunning, cornerRadius = 18.dp) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Rounded.Layers,
              contentDescription = null,
              tint = tokens.accentPrimary,
              modifier = Modifier.size(22.dp),
            )
            Spacer(Modifier.width(10.dp))
            Text(
              text = "FLOATING OVERLAY & PERMISSIONS",
              style = MaterialTheme.typography.titleSmall,
              color = tokens.accentPrimary,
              fontWeight = FontWeight.Bold,
            )
          }
          Spacer(Modifier.height(12.dp))

          PermissionStatusRow(
            label = "Display Over Other Apps",
            granted = hasOverlayPermission,
            actionLabel = if (hasOverlayPermission) "Manage" else "Grant",
            onAction = { OverlayController.openOverlayPermissionSettings(context) },
            testTag = "overlay_permission_button",
          )

          if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Spacer(Modifier.height(8.dp))
            PermissionStatusRow(
              label = "Foreground Service Notification",
              granted = hasNotificationPermission,
              actionLabel = if (hasNotificationPermission) "Granted" else "Allow",
              onAction = {
                if (!hasNotificationPermission) {
                  notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
              },
              testTag = "notification_permission_button",
            )
          }

          Spacer(Modifier.height(14.dp))
          NeonGradientButton(
            text =
              when {
                uiState.isOverlayRunning -> "Stop Floating X Overlay"
                hasOverlayPermission -> "Launch Floating X Overlay"
                else -> "Grant Overlay Permission"
              },
            onClick = {
              if (
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                  !hasNotificationPermission &&
                  hasOverlayPermission
              ) {
                notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
              }
              onToggleOverlay()
            },
            testTag = "settings_overlay_toggle_button",
            icon =
              when {
                uiState.isOverlayRunning -> Icons.Rounded.Stop
                hasOverlayPermission -> Icons.Rounded.PlayArrow
                else -> Icons.Rounded.OpenInNew
              },
            modifier = Modifier.fillMaxWidth(),
          )
        }
      }

      // Floating Button Size
      item(key = "button_size_card") {
        GlassCard(cornerRadius = 18.dp) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Rounded.Tune,
                contentDescription = null,
                tint = tokens.accentPrimary,
                modifier = Modifier.size(20.dp),
              )
              Spacer(Modifier.width(8.dp))
              Text(
                text = "FLOATING BUTTON SIZE",
                style = MaterialTheme.typography.titleSmall,
                color = tokens.accentPrimary,
                fontWeight = FontWeight.Bold,
              )
            }
            Text(
              text = "${settings.buttonSizeDp} dp",
              style = MaterialTheme.typography.labelMedium,
              color = TextPrimary,
            )
          }

          Spacer(Modifier.height(12.dp))

          // Live Preview of Floating X Button
          Box(
            modifier =
              Modifier.fillMaxWidth()
                .height(100.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(NavyDeep.copy(alpha = 0.85f))
                .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(14.dp)),
            contentAlignment = Alignment.Center,
          ) {
            val previewSize = settings.buttonSizeDp.dp
            Box(
              modifier =
                Modifier.size(previewSize)
                  .clip(CircleShape)
                  .background(NavySurfaceElevated)
                  .border(
                    width = 1.5.dp,
                    brush = Brush.linearGradient(listOf(tokens.accentPrimary, tokens.accentSecondary)),
                    shape = CircleShape,
                  ),
              contentAlignment = Alignment.Center,
            ) {
              XylenLogoMark(size = previewSize * 0.72f, animatedGlow = true)
            }
          }

          Spacer(Modifier.height(10.dp))

          Slider(
            value = settings.buttonSizeDp.toFloat(),
            onValueChange = { onUpdateButtonSize(it.roundToInt()) },
            valueRange = 44f..84f,
            colors =
              SliderDefaults.colors(
                thumbColor = tokens.accentPrimary,
                activeTrackColor = tokens.accentPrimary,
                inactiveTrackColor = NavyDeep,
              ),
            modifier = Modifier.testTag("button_size_slider"),
          )

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            FloatingButtonSize.entries.forEach { preset ->
              val selected = settings.buttonSizeDp in (preset.sizeDp - 3)..(preset.sizeDp + 3)
              Box(
                modifier =
                  Modifier.weight(1f)
                    .minimumInteractiveComponentSize()
                    .clip(RoundedCornerShape(10.dp))
                    .background(
                      if (selected) tokens.accentPrimary.copy(alpha = 0.22f)
                      else NavyDeep.copy(alpha = 0.82f)
                    )
                    .border(
                      width = 1.dp,
                      color =
                        if (selected) tokens.accentPrimary else Color.White.copy(alpha = 0.10f),
                      shape = RoundedCornerShape(10.dp),
                    )
                    .clickable { onUpdateButtonSize(preset.sizeDp) }
                    .padding(vertical = 8.dp)
                    .testTag("size_preset_${preset.label.lowercase()}"),
                contentAlignment = Alignment.Center,
              ) {
                Text(
                  text = preset.label,
                  style = MaterialTheme.typography.labelLarge,
                  color = if (selected) tokens.accentPrimary else TextSecondary,
                )
              }
            }
          }
        }
      }

      // Overlay Position
      item(key = "overlay_position_card") {
        GlassCard(cornerRadius = 18.dp) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Text(
              text = "OVERLAY POSITION",
              style = MaterialTheme.typography.titleSmall,
              color = tokens.accentPrimary,
              fontWeight = FontWeight.Bold,
            )
            Text(
              text = "X: ${settings.overlayX}px  Y: ${settings.overlayY}px",
              style = MaterialTheme.typography.labelMedium,
              color = TextSecondary,
            )
          }
          Spacer(Modifier.height(4.dp))
          Text(
            text = "Drag the floating X button anywhere on screen, or snap to a preset anchor.",
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary,
          )
          Spacer(Modifier.height(12.dp))
          FlowRow(
            maxItemsInEachRow = 3,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth(),
          ) {
            OverlayAnchorPreset.entries.forEach { preset ->
              val selected = settings.anchorPreset == preset
              Box(
                modifier =
                  Modifier.weight(1f)
                    .minimumInteractiveComponentSize()
                    .clip(RoundedCornerShape(10.dp))
                    .background(
                      if (selected) tokens.accentSecondary.copy(alpha = 0.24f)
                      else NavyDeep.copy(alpha = 0.82f)
                    )
                    .border(
                      width = 1.dp,
                      color =
                        if (selected) tokens.accentSecondary else Color.White.copy(alpha = 0.10f),
                      shape = RoundedCornerShape(10.dp),
                    )
                    .clickable {
                      onApplyAnchorPreset(preset, metrics.widthPixels, metrics.heightPixels)
                    }
                    .padding(horizontal = 8.dp, vertical = 10.dp)
                    .testTag("anchor_preset_${preset.id}"),
                contentAlignment = Alignment.Center,
              ) {
                Text(
                  text = preset.label,
                  style = MaterialTheme.typography.bodySmall,
                  fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                  color = if (selected) TextPrimary else TextSecondary,
                )
              }
            }
          }
          Spacer(Modifier.height(10.dp))
          NeonOutlinedButton(
            text = "Reset Overlay Position",
            onClick = { onResetPosition(metrics.widthPixels, metrics.heightPixels) },
            testTag = "reset_overlay_position_button",
            icon = Icons.Rounded.RestartAlt,
            modifier = Modifier.fillMaxWidth(),
          )
        }
      }

      // Theme Settings
      item(key = "theme_card") {
        GlassCard(cornerRadius = 18.dp) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Rounded.Palette,
              contentDescription = null,
              tint = tokens.accentPrimary,
              modifier = Modifier.size(20.dp),
            )
            Spacer(Modifier.width(8.dp))
            Text(
              text = "THEME & VISUAL FX",
              style = MaterialTheme.typography.titleSmall,
              color = tokens.accentPrimary,
              fontWeight = FontWeight.Bold,
            )
          }
          Spacer(Modifier.height(12.dp))

          Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            XylenThemePreset.entries.forEach { preset ->
              val selected = settings.themePreset == preset
              Row(
                modifier =
                  Modifier.fillMaxWidth()
                    .minimumInteractiveComponentSize()
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                      if (selected) NavySurfaceElevated.copy(alpha = 0.92f)
                      else NavyDeep.copy(alpha = 0.78f)
                    )
                    .border(
                      width = if (selected) 1.5.dp else 1.dp,
                      brush =
                        if (selected) {
                          Brush.linearGradient(
                            listOf(Color(preset.primaryHex), Color(preset.secondaryHex))
                          )
                        } else {
                          Brush.linearGradient(
                            listOf(Color.White.copy(alpha = 0.08f), Color.White.copy(alpha = 0.06f))
                          )
                        },
                      shape = RoundedCornerShape(12.dp),
                    )
                    .clickable { onUpdateThemePreset(preset) }
                    .padding(horizontal = 12.dp, vertical = 10.dp)
                    .testTag("theme_preset_${preset.id}"),
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Box(
                  modifier =
                    Modifier.size(28.dp)
                      .clip(CircleShape)
                      .background(
                        Brush.linearGradient(
                          listOf(Color(preset.primaryHex), Color(preset.secondaryHex))
                        )
                      )
                )
                Spacer(Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                  Text(
                    text = preset.label,
                    style = MaterialTheme.typography.titleSmall,
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                  )
                  Text(
                    text = preset.subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                  )
                }
              }
            }
          }

          Spacer(Modifier.height(12.dp))
          Text(
            text = "Glass Card Density: ${(settings.glassOpacity * 100).roundToInt()}%",
            style = MaterialTheme.typography.labelLarge,
            color = TextSecondary,
          )
          Slider(
            value = settings.glassOpacity,
            onValueChange = onUpdateGlassOpacity,
            valueRange = 0.50f..0.95f,
            colors =
              SliderDefaults.colors(
                thumbColor = tokens.accentPrimary,
                activeTrackColor = tokens.accentPrimary,
                inactiveTrackColor = NavyDeep,
              ),
            modifier = Modifier.testTag("glass_opacity_slider"),
          )

          Text(
            text = "Neon Glow Intensity: ${(settings.glowIntensity * 100).roundToInt()}%",
            style = MaterialTheme.typography.labelLarge,
            color = TextSecondary,
          )
          Slider(
            value = settings.glowIntensity,
            onValueChange = onUpdateGlowIntensity,
            valueRange = 0.35f..1.35f,
            colors =
              SliderDefaults.colors(
                thumbColor = tokens.accentSecondary,
                activeTrackColor = tokens.accentSecondary,
                inactiveTrackColor = NavyDeep,
              ),
            modifier = Modifier.testTag("glow_intensity_slider"),
          )

          Row(
            modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = "Auto-Highlight Conflicts",
                style = MaterialTheme.typography.titleSmall,
                color = TextPrimary,
              )
              Text(
                text = "Warn when mutually exclusive enchantments are selected",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
              )
            }
            Switch(
              checked = settings.autoCheckConflicts,
              onCheckedChange = onUpdateAutoCheckConflicts,
              colors =
                SwitchDefaults.colors(
                  checkedThumbColor = NavyVoid,
                  checkedTrackColor = tokens.accentPrimary,
                  uncheckedThumbColor = TextSecondary,
                  uncheckedTrackColor = NavyDeep,
                ),
              modifier = Modifier.testTag("auto_conflict_switch"),
            )
          }
        }
      }

      // App Info & XylenMC Branding
      item(key = "about_card") {
        GlassCard(highlighted = true, cornerRadius = 18.dp) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            XylenLogoMark(size = 52.dp, animatedGlow = true)
            Spacer(Modifier.width(14.dp))
            Column {
              Text(
                text = "XYLENMC CLIENT EDITION",
                style = MaterialTheme.typography.titleMedium,
                color = TextPrimary,
                fontWeight = FontWeight.Bold,
              )
              Text(
                text = "Version 1.0.0 • Native Android Edition",
                style = MaterialTheme.typography.labelMedium,
                color = tokens.accentPrimary,
              )
            }
          }
          Spacer(Modifier.height(12.dp))
          Text(
            text =
              "Built natively with Kotlin, Jetpack Compose, and Android Foreground Overlay services for Minecraft Bedrock Edition loadout planning.",
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary,
          )
          Spacer(Modifier.height(8.dp))
          Row(
            modifier =
              Modifier.fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(NavyDeep.copy(alpha = 0.8f))
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Icon(
              imageVector = Icons.Rounded.NotificationsActive,
              contentDescription = null,
              tint = tokens.accentSecondary,
              modifier = Modifier.size(16.dp),
            )
            Spacer(Modifier.width(8.dp))
            Text(
              text = "Client-side planning tool only. No packet injection or server modification.",
              style = MaterialTheme.typography.bodySmall,
              color = TextSecondary,
            )
          }
        }
      }

      item(key = "bottom_spacer") { Spacer(Modifier.height(12.dp)) }
    }
  }
}

@Composable
private fun PermissionStatusRow(
  label: String,
  granted: Boolean,
  actionLabel: String,
  onAction: () -> Unit,
  testTag: String,
) {
  val statusColor = if (granted) NeonEmerald else NeonAmber
  Row(
    modifier =
      Modifier.fillMaxWidth()
        .clip(RoundedCornerShape(12.dp))
        .background(NavyDeep.copy(alpha = 0.8f))
        .border(1.dp, statusColor.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
        .padding(horizontal = 12.dp, vertical = 10.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween,
  ) {
    Column(modifier = Modifier.weight(1f)) {
      Text(
        text = label,
        style = MaterialTheme.typography.bodyMedium,
        color = TextPrimary,
        fontWeight = FontWeight.SemiBold,
      )
      Text(
        text = if (granted) "Permission granted" else "Action required",
        style = MaterialTheme.typography.labelSmall,
        color = statusColor,
      )
    }
    Box(
      modifier =
        Modifier.minimumInteractiveComponentSize()
          .clip(RoundedCornerShape(10.dp))
          .background(statusColor.copy(alpha = 0.18f))
          .clickable(onClick = onAction)
          .padding(horizontal = 12.dp, vertical = 8.dp)
          .testTag(testTag),
      contentAlignment = Alignment.Center,
    ) {
      Text(
        text = actionLabel,
        style = MaterialTheme.typography.labelLarge,
        color = statusColor,
        fontWeight = FontWeight.Bold,
      )
    }
  }
}
