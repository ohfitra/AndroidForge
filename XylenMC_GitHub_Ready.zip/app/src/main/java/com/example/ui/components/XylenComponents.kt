package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.theme.LocalXylenTokens
import com.example.ui.theme.NavyDeep
import com.example.ui.theme.NavySurface
import com.example.ui.theme.NavySurfaceElevated
import com.example.ui.theme.NavyVoid
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun CyberBackground(
  modifier: Modifier = Modifier,
  content: @Composable () -> Unit,
) {
  val tokens = LocalXylenTokens.current
  Box(
    modifier =
      modifier
        .fillMaxSize()
        .background(NavyVoid)
        .drawBehind {
          val w = size.width
          val h = size.height
          // Top-left cyan ambient glow
          drawCircle(
            brush =
              Brush.radialGradient(
                colors =
                  listOf(
                    tokens.accentPrimary.copy(alpha = 0.16f * tokens.glowIntensity),
                    Color.Transparent,
                  ),
                center = Offset(w * 0.15f, h * 0.08f),
                radius = w * 0.85f,
              ),
            radius = w * 0.85f,
            center = Offset(w * 0.15f, h * 0.08f),
          )
          // Bottom-right purple ambient glow
          drawCircle(
            brush =
              Brush.radialGradient(
                colors =
                  listOf(
                    tokens.accentSecondary.copy(alpha = 0.18f * tokens.glowIntensity),
                    Color.Transparent,
                  ),
                center = Offset(w * 0.88f, h * 0.82f),
                radius = w * 0.90f,
              ),
            radius = w * 0.90f,
            center = Offset(w * 0.88f, h * 0.82f),
          )
          // Subtle futuristic HUD grid
          val step = 44.dp.toPx()
          val gridColor = Color.White.copy(alpha = 0.025f)
          var x = 0f
          while (x < w) {
            drawLine(gridColor, Offset(x, 0f), Offset(x, h), strokeWidth = 1f)
            x += step
          }
          var y = 0f
          while (y < h) {
            drawLine(gridColor, Offset(0f, y), Offset(w, y), strokeWidth = 1f)
            y += step
          }
        }
  ) {
    content()
  }
}

@Composable
fun XylenLogoMark(
  modifier: Modifier = Modifier,
  size: Dp = 44.dp,
  animatedGlow: Boolean = true,
) {
  val tokens = LocalXylenTokens.current
  val logoDesc = stringResource(R.string.cd_xylen_logo)
  val pulse =
    if (animatedGlow) {
      val transition = rememberInfiniteTransition(label = "xylen_logo_pulse")
      val value by
        transition.animateFloat(
          initialValue = 0.72f,
          targetValue = 1.0f,
          animationSpec =
            infiniteRepeatable(
              animation = tween(1800, easing = FastOutSlowInEasing),
              repeatMode = RepeatMode.Reverse,
            ),
          label = "pulse_alpha",
        )
      value
    } else {
      0.9f
    }

  Canvas(
    modifier =
      modifier
        .size(size)
        .semantics { contentDescription = logoDesc }
  ) {
    val w = this.size.width
    val h = this.size.height
    val cx = w / 2f
    val cy = h / 2f

    // Outer ambient glow
    drawCircle(
      brush =
        Brush.radialGradient(
          colors =
            listOf(
              tokens.accentPrimary.copy(alpha = 0.30f * pulse * tokens.glowIntensity),
              tokens.accentSecondary.copy(alpha = 0.14f * pulse * tokens.glowIntensity),
              Color.Transparent,
            ),
          center = Offset(cx, cy),
          radius = w * 0.56f,
        ),
      radius = w * 0.56f,
      center = Offset(cx, cy),
    )

    // Octagonal cyber frame
    val cut = w * 0.22f
    val pad = w * 0.06f
    val framePath =
      Path().apply {
        moveTo(pad + cut, pad)
        lineTo(w - pad - cut, pad)
        lineTo(w - pad, pad + cut)
        lineTo(w - pad, h - pad - cut)
        lineTo(w - pad - cut, h - pad)
        lineTo(pad + cut, h - pad)
        lineTo(pad, h - pad - cut)
        lineTo(pad, pad + cut)
        close()
      }
    drawPath(
      path = framePath,
      brush =
        Brush.linearGradient(
          colors = listOf(NavySurfaceElevated.copy(alpha = 0.94f), NavyDeep.copy(alpha = 0.96f))
        ),
    )
    drawPath(
      path = framePath,
      brush = Brush.linearGradient(listOf(tokens.accentPrimary, tokens.accentSecondary)),
      style = Stroke(width = (w * 0.045f).coerceAtLeast(1.5f), join = StrokeJoin.Round),
    )

    // Geometric razor-sharp cyber X blades
    val inset = w * 0.27f
    val strokeW = (w * 0.135f).coerceAtLeast(3f)

    // Primary diagonal (\)
    drawLine(
      brush = Brush.linearGradient(listOf(tokens.accentPrimary, tokens.accentTertiary)),
      start = Offset(inset, inset),
      end = Offset(w - inset, h - inset),
      strokeWidth = strokeW,
      cap = StrokeCap.Round,
    )
    // Secondary diagonal (/)
    drawLine(
      brush = Brush.linearGradient(listOf(tokens.accentSecondary, tokens.accentPrimary)),
      start = Offset(w - inset, inset),
      end = Offset(inset, h - inset),
      strokeWidth = strokeW,
      cap = StrokeCap.Round,
    )
    // Inner luminous core highlight
    drawCircle(
      color = Color.White.copy(alpha = 0.85f * pulse),
      radius = (w * 0.065f).coerceAtLeast(1.8f),
      center = Offset(cx, cy),
    )
  }
}

@Composable
fun GlassCard(
  modifier: Modifier = Modifier,
  highlighted: Boolean = false,
  cornerRadius: Dp = 18.dp,
  contentPadding: PaddingValues = PaddingValues(16.dp),
  content: @Composable ColumnScope.() -> Unit,
) {
  val tokens = LocalXylenTokens.current
  val shape = RoundedCornerShape(cornerRadius)
  val borderBrush =
    if (highlighted) {
      Brush.linearGradient(listOf(tokens.accentPrimary, tokens.accentSecondary))
    } else {
      Brush.linearGradient(
        listOf(
          tokens.accentPrimary.copy(alpha = 0.28f * tokens.glowIntensity),
          Color.White.copy(alpha = 0.10f),
          tokens.accentSecondary.copy(alpha = 0.24f * tokens.glowIntensity),
        )
      )
    }

  val containerColor by
    animateColorAsState(
      targetValue =
        if (highlighted) {
          NavySurfaceElevated.copy(alpha = (tokens.glassOpacity + 0.08f).coerceAtMost(0.96f))
        } else {
          NavySurface.copy(alpha = tokens.glassOpacity)
        },
      animationSpec = tween(220),
      label = "glass_card_color",
    )

  Surface(
    modifier = modifier.border(width = if (highlighted) 1.5.dp else 1.dp, brush = borderBrush, shape = shape),
    shape = shape,
    color = containerColor,
    tonalElevation = 0.dp,
  ) {
    Box(
      modifier =
        Modifier.background(
          Brush.verticalGradient(
            listOf(Color.White.copy(alpha = 0.05f), Color.Transparent)
          )
        )
    ) {
      Column(modifier = Modifier.padding(contentPadding), content = content)
    }
  }
}

@Composable
fun NeonGradientButton(
  text: String,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  testTag: String,
  icon: ImageVector? = null,
  enabled: Boolean = true,
) {
  val tokens = LocalXylenTokens.current
  val shape = RoundedCornerShape(14.dp)
  Button(
    onClick = onClick,
    enabled = enabled,
    shape = shape,
    colors =
      ButtonDefaults.buttonColors(
        containerColor = Color.Transparent,
        contentColor = NavyVoid,
        disabledContainerColor = NavySurfaceElevated.copy(alpha = 0.5f),
        disabledContentColor = TextSecondary.copy(alpha = 0.45f),
      ),
    contentPadding = PaddingValues(0.dp),
    modifier = modifier.minimumInteractiveComponentSize().height(48.dp).testTag(testTag),
  ) {
    Box(
      modifier =
        Modifier.fillMaxSize()
          .background(
            brush =
              if (enabled) {
                Brush.linearGradient(listOf(tokens.accentPrimary, tokens.accentSecondary))
              } else {
                Brush.linearGradient(
                  listOf(
                    NavySurfaceElevated.copy(alpha = 0.6f),
                    NavySurface.copy(alpha = 0.6f),
                  )
                )
              },
            shape = shape,
          )
          .padding(horizontal = 16.dp),
      contentAlignment = Alignment.Center,
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
      ) {
        if (icon != null) {
          Icon(
            imageVector = icon,
            contentDescription = null,
            tint = if (enabled) NavyVoid else TextSecondary.copy(alpha = 0.5f),
            modifier = Modifier.size(18.dp),
          )
          Spacer(Modifier.width(8.dp))
        }
        Text(
          text = text,
          style = MaterialTheme.typography.labelLarge,
          fontWeight = FontWeight.Bold,
          color = if (enabled) NavyVoid else TextSecondary.copy(alpha = 0.5f),
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
      }
    }
  }
}

@Composable
fun NeonOutlinedButton(
  text: String,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  testTag: String,
  icon: ImageVector? = null,
  accentColor: Color? = null,
  enabled: Boolean = true,
) {
  val tokens = LocalXylenTokens.current
  val tint = accentColor ?: tokens.accentPrimary
  OutlinedButton(
    onClick = onClick,
    enabled = enabled,
    shape = RoundedCornerShape(14.dp),
    border =
      BorderStroke(
        width = 1.dp,
        color = if (enabled) tint.copy(alpha = 0.55f) else TextSecondary.copy(alpha = 0.25f),
      ),
    colors =
      ButtonDefaults.outlinedButtonColors(
        containerColor = tint.copy(alpha = 0.08f),
        contentColor = tint,
      ),
    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
    modifier = modifier.minimumInteractiveComponentSize().height(48.dp).testTag(testTag),
  ) {
    if (icon != null) {
      Icon(
        imageVector = icon,
        contentDescription = null,
        modifier = Modifier.size(18.dp),
      )
      Spacer(Modifier.width(8.dp))
    }
    Text(
      text = text,
      style = MaterialTheme.typography.labelLarge,
      maxLines = 1,
      overflow = TextOverflow.Ellipsis,
    )
  }
}

@Composable
fun OverlayStatusPill(
  isRunning: Boolean,
  hasPermission: Boolean,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  testTag: String = "overlay_status_pill",
) {
  val tokens = LocalXylenTokens.current
  val dotColor =
    when {
      isRunning -> NeonEmerald
      hasPermission -> tokens.accentPrimary
      else -> MaterialTheme.colorScheme.secondary
    }
  val label =
    when {
      isRunning -> "OVERLAY ON"
      hasPermission -> "LAUNCH HUD"
      else -> "ENABLE HUD"
    }

  Row(
    modifier =
      modifier
        .minimumInteractiveComponentSize()
        .clip(RoundedCornerShape(50))
        .background(NavySurfaceElevated.copy(alpha = 0.88f))
        .border(
          width = 1.dp,
          brush =
            Brush.linearGradient(
              listOf(dotColor.copy(alpha = 0.7f), tokens.accentSecondary.copy(alpha = 0.5f))
            ),
          shape = RoundedCornerShape(50),
        )
        .clickable(role = Role.Button, onClick = onClick)
        .padding(horizontal = 14.dp, vertical = 10.dp)
        .testTag(testTag),
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(dotColor))
    Spacer(Modifier.width(8.dp))
    Text(
      text = label,
      style = MaterialTheme.typography.labelMedium,
      color = TextPrimary,
      fontWeight = FontWeight.Bold,
    )
  }
}

@Composable
fun SectionHeader(
  title: String,
  subtitle: String? = null,
  trailing: (@Composable () -> Unit)? = null,
) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Column(modifier = Modifier.weight(1f)) {
      Text(
        text = title.uppercase(),
        style = MaterialTheme.typography.titleSmall,
        color = LocalXylenTokens.current.accentPrimary,
        fontWeight = FontWeight.Bold,
      )
      if (subtitle != null) {
        Spacer(Modifier.height(2.dp))
        Text(
          text = subtitle,
          style = MaterialTheme.typography.bodySmall,
          color = TextSecondary,
        )
      }
    }
    if (trailing != null) {
      trailing()
    }
  }
}
