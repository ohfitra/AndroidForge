package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.model.XylenSettings
import com.example.model.XylenThemePreset

@Immutable
data class XylenVisualTokens(
  val accentPrimary: Color,
  val accentSecondary: Color,
  val accentTertiary: Color,
  val glassOpacity: Float,
  val glowIntensity: Float,
  val navyBg: Color = NavyVoid,
  val navyCard: Color = NavySurface,
) {
  val accentGradient: Brush
    get() = Brush.linearGradient(listOf(accentPrimary, accentSecondary))

  val subtleBorderGradient: Brush
    get() =
      Brush.linearGradient(
        listOf(
          accentPrimary.copy(alpha = (0.55f * glowIntensity).coerceIn(0.2f, 0.9f)),
          accentSecondary.copy(alpha = (0.45f * glowIntensity).coerceIn(0.18f, 0.85f)),
        )
      )
}

val LocalXylenTokens = staticCompositionLocalOf {
  XylenVisualTokens(
    accentPrimary = NeonCyan,
    accentSecondary = NeonPurple,
    accentTertiary = NeonElectricBlue,
    glassOpacity = 0.80f,
    glowIntensity = 1.0f,
  )
}

private val XylenShapes =
  Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
  )

@Composable
fun XylenMCTheme(
  settings: XylenSettings = XylenSettings(),
  content: @Composable () -> Unit,
) {
  val preset: XylenThemePreset = settings.themePreset
  val primary = Color(preset.primaryHex)
  val secondary = Color(preset.secondaryHex)
  val tertiary = Color(preset.tertiaryHex)

  val colorScheme =
    darkColorScheme(
      primary = primary,
      onPrimary = NavyVoid,
      primaryContainer = primary.copy(alpha = 0.16f),
      onPrimaryContainer = primary,
      secondary = secondary,
      onSecondary = TextPrimary,
      secondaryContainer = secondary.copy(alpha = 0.20f),
      onSecondaryContainer = TextPrimary,
      tertiary = tertiary,
      onTertiary = NavyVoid,
      background = NavyVoid,
      onBackground = TextPrimary,
      surface = NavyDeep,
      onSurface = TextPrimary,
      surfaceVariant = NavySurface,
      onSurfaceVariant = TextSecondary,
      surfaceContainerLowest = NavyVoid,
      surfaceContainerLow = NavyDeep,
      surfaceContainer = NavySurface,
      surfaceContainerHigh = NavySurfaceElevated,
      outline = primary.copy(alpha = 0.35f),
      outlineVariant = NavyGlassStroke,
      error = NeonRose,
      onError = NavyVoid,
    )

  val tokens =
    XylenVisualTokens(
      accentPrimary = primary,
      accentSecondary = secondary,
      accentTertiary = tertiary,
      glassOpacity = settings.glassOpacity,
      glowIntensity = settings.glowIntensity,
    )

  CompositionLocalProvider(LocalXylenTokens provides tokens) {
    MaterialTheme(
      colorScheme = colorScheme,
      typography = XylenTypography,
      shapes = XylenShapes,
      content = content,
    )
  }
}
